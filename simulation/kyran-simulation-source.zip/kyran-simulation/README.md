# Simulateur KYRAN

Logiciel interne, hors ligne : joue des parties complètes de KYRAN par algorithme (aucune IA de langage
pendant les parties), enregistre toutes les mesures en CSV, puis produit un rapport de tableaux croisés.

## Utilisation

```
node src/run.mjs --games 10 --workers 1 --out resultats/essai           # essai
node src/run.mjs --games 10000 --out resultats/officielle-10000          # campagne complète
node src/run.mjs --games 2000 --variant sans_pouvoirs --out resultats/sp # variante
PYTHONIOENCODING=utf-8 python analyse.py resultats/officielle-10000      # rapport.md + tableaux.xlsx
PYTHONIOENCODING=utf-8 python compare.py resultats/officielle-10000 resultats/variante-* --max-game 1500   # variantes côte à côte
```

Options : `--seed` (rejouabilité), `--workers` (défaut : cœurs − 1), `--variant`
(`officielle`, `sans_pouvoirs`, `sans_mystique`, `sans_regle_or`, `vies3`, `vies7`, `voile_obligatoire`, `mix`),
`--styles`, `--levels` (listes séparées par des virgules).

Chaque partie : 3 à 6 joueurs (à parts égales), un style et un niveau tirés au hasard par siège, une graine
propre. Même graine = même partie.

## Fichiers

- `src/engine.mjs` : règles officielles (machine à états, sans affichage).
- `src/ai.mjs` : joueurs artificiels, 50 profils (10 styles × 5 niveaux).
  Styles : calculateur, audacieux (+0,6 pli), tête brûlée (+1,2), prudent (−0,6), imprévisible (15 % de
  coups au hasard), saboteur (vise le meneur), opportuniste (ose plus quand il est dernier, moins quand il
  mène), distrait (oublie les cartes déjà vues), flambeur (pose ses cartes spéciales tôt), économe (les garde).
  Niveaux : novice (45 % d'erreurs), débutant (20 %), confirmé (paris évalués par 16 simulations
  Monte-Carlo), expert (32 pour les paris, 12 par carte jouée), maître (64 et 24).
  Aucun joueur ne voit la main des autres : les simulations redistribuent les cartes inconnues.
- `src/game.mjs` : une partie complète + journal des mesures + contrôles d'intégrité à chaque manche.
- `src/run.mjs` : lancement en parallèle, écriture des CSV.
- `analyse.py` : rapport en 11 sections (intégrité, durée, victoire, paris, Vies, manche Mystique, cartes,
  Pouvoirs, suspense, force de la main, déroulé des plis).
- `tests/regles.test.mjs` : 13 tests des règles, scénario par scénario (`node --test tests/`).

Tables produites : `games` (1 ligne par partie), `players` (1 par joueur), `rounds` (1 par joueur et
par manche), `plays` (1 par carte posée). `plays` dépasse la limite d'Excel : l'ouvrir avec pandas.

## Règles appliquées et interprétations

- 36 Nombres (1 à 36), 1 Mystique, 8 Pouvoirs ; à 3-4 joueurs seulement les Pouvoirs 11, 27, 20 et 3.
- 5 Vies. Manches 7, 6, 5, 4, 3, 2, puis manche Mystique (1 carte) ; le cycle recommence jusqu'à la fin.
  Les manches impossibles faute de cartes sont retirées.
- Donneur tournant ; paris et entame à gauche du donneur. Règle d'or : somme des paris ≠ nombre de plis
  (le dernier ajuste) — appliquée aussi en manche Mystique (interprétation).
- Pli : plus forte valeur ; à égalité, le Pouvoir bat le Nombre. Pari raté : −|écart| Vies (−1 en manche Mystique).
- Fin au premier joueur à 0 Vie ; le plus de Vies gagne. Égalité : manches Mystique de départage, sans perte
  de Vies (interprétation), jusqu'à 10 fois, puis victoire partagée.
- Mystique hors manche Mystique : 0 ou 37 au choix. Clairvoyance, Sceau, Bénédiction, Voile : selon la règle
  (Sceau et Bénédiction annulés si joués en dernier, Voile annulé si joué en premier).
- La Bénédiction ne fait jamais poser la Mystique comme « carte la plus faible » (interprétation).
- Le Voile peut être refusé par celui qui le pose (interprétation). La variante `voile_obligatoire` mesure l'autre lecture : échange imposé dès qu'un adversaire a posé une carte.
- Hasard : les donnes et le tirage du Sceau ont deux générateurs séparés. À graine égale, les donnes sont
  donc les mêmes quels que soient les choix des joueurs.
- Durée « estimée » : modèle simple (temps de distribution, de pari et de pose), pas une mesure réelle.
