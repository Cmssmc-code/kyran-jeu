"""Analyse des parties simulées : rapport.md (tableaux croisés) + tableaux.xlsx.

    python analyse.py resultats/officielle-10000
"""
import sys
from pathlib import Path

import numpy as np
import pandas as pd

D = Path(sys.argv[1] if len(sys.argv) > 1 else "resultats/essai")
g = pd.read_csv(D / "games.csv")
pl = pd.read_csv(D / "players.csv")
r = pd.read_csv(D / "rounds.csv")
p = pd.read_csv(D / "plays.csv")

out, sheets = [], {}


def h(t):
    out.append(f"\n## {t}\n")


def note(t):
    out.append(t + "\n")


def tab(name, df, pct=False, digits=3):
    df = df.copy()
    if pct:
        df = (df * 100).round(1)
    else:
        df = df.round(digits)
    sheets[f"{len(sheets) + 1:02d} {name.translate(str.maketrans('', '', '[]:*?/\\'))}"[:31]] = df
    out.append(f"**{name}**\n\n" + df.to_markdown() + "\n")


normal = r[r.tiebreak == 0].copy()
normal["exact"] = (normal["diff"] == 0).astype(int)
nm = normal[normal.mystic == 0]
my = normal[normal.mystic == 1]

# ---------------------------------------------------------------- intégrité
h("1. Volume et intégrité")
err = (D / "erreurs.txt")
note(f"- Parties : {len(g)} ; joueurs : {len(pl)} ; manches-joueur : {len(r)} ; cartes posées : {len(p)}")
note(f"- Erreurs moteur : {len(err.read_text().splitlines()) if err.exists() else 0}")
note(f"- Parties avec plusieurs gagnants (départage épuisé) : {(g.n_winners > 1).sum()}")
note(f"- Temps de calcul moyen par partie : {g.ms.mean():.0f} ms")

# ---------------------------------------------------------------- durée
h("2. Durée et rythme")
tab("Durée par nombre de joueurs", g.groupby("n").agg(
    minutes_moy=("est_minutes", "mean"), minutes_med=("est_minutes", "median"),
    minutes_p90=("est_minutes", lambda s: s.quantile(.9)), manches_moy=("rounds", "mean"),
    cycles_complets=("full_cycles", "mean"), depart_age=("tiebreak_rounds", lambda s: (s > 0).mean()),
    marge_moy=("margin", "mean")))
tab("Répartition du nombre de manches (en %)", pd.crosstab(g.rounds.clip(upper=16), g.n, normalize="columns"), pct=True)
tab("Manche (nb de cartes) où la partie se termine (en %)", pd.crosstab(g.last_cards, g.n, normalize="columns"), pct=True)
tab("Joueurs éliminés (0 Vie) en fin de partie (en %)",
    pd.crosstab(g.eliminated.fillna("").astype(str).str.split("|").map(lambda x: len([y for y in x if y != ""])), g.n,
                normalize="columns"), pct=True)

# ---------------------------------------------------------------- victoire
h("3. Qui gagne ?")
note("Part de victoire = 1/nb de gagnants. Référence au hasard = 1/n.")
pl["base"] = 1 / pl.n
pl["indice"] = pl.win_share / pl.base
tab("Indice de victoire par place (1 = neutre ; place 0 = à gauche du 1er donneur)",
    pl.pivot_table(index="seat_rel", columns="n", values="indice", aggfunc="mean"))
tab("Indice de victoire par niveau et n", pl.pivot_table(index="level", columns="n", values="indice", aggfunc="mean"))
tab("Indice de victoire par style et n", pl.pivot_table(index="style", columns="n", values="indice", aggfunc="mean"))
tab("Indice de victoire style × niveau", pl.pivot_table(index="style", columns="level", values="indice", aggfunc="mean"))
tab("Vies finales moyennes style × niveau", pl.pivot_table(index="style", columns="level", values="final_lives", aggfunc="mean"))

# habileté vs chance : parties mêlant experts et débutants
LEVELS = [x for x in ["novice", "debutant", "confirme", "expert", "maitre"] if x in set(pl.level)]
for df in (pl, r, p):
    df["level"] = pd.Categorical(df["level"], LEVELS, ordered=True)
normal["level"] = pd.Categorical(normal["level"], LEVELS, ordered=True)
nm = normal[normal.mystic == 0]
my = normal[normal.mystic == 1]
pl["lvl"] = pl.level.cat.codes
strong = pl[pl.lvl >= len(LEVELS) - 2]   # expert, maître
weak = pl[pl.lvl <= 1]                   # novice, débutant
both = set(strong.game) & set(weak.game)
if both:
    note(f"- Parties où un expert ou un maître affronte un novice ou un débutant : {len(both)}. Indice de victoire des forts : "
         f"{strong[strong.game.isin(both)].indice.mean():.2f} ; des faibles : {weak[weak.game.isin(both)].indice.mean():.2f}.")
win_lvl = pl.groupby("level", observed=True).indice.mean()
if len(LEVELS) > 1:
    note(f"- Rapport de victoire {LEVELS[-1]} / {LEVELS[0]} (toutes parties) : {win_lvl[LEVELS[-1]] / win_lvl[LEVELS[0]]:.2f}")
tab("Indice de victoire par niveau selon le niveau moyen des adversaires (0 = novices … 4 = maîtres)",
    pl.assign(adversaires=pd.cut(pl.opp_level, [-0.01, 1.2, 1.8, 2.2, 2.8, 4.01], labels=["très faibles", "faibles", "moyens", "forts", "très forts"]))
    .pivot_table(index="level", columns="adversaires", values="indice", aggfunc="mean", observed=True))
tab("Nombre de joueurs par profil (style × niveau)", pd.crosstab(pl["style"], pl["level"]), digits=0)
# corrélation exactitude des paris → victoire
pl["taux_exact"] = pl.rounds_exact / pl.rounds_played.replace(0, np.nan)
pl["q_exact"] = pd.qcut(pl.taux_exact.rank(method="first"), 5, labels=["Q1 bas", "Q2", "Q3", "Q4", "Q5 haut"])
tab("Indice de victoire selon la précision des paris (quintiles)", pl.pivot_table(index="q_exact", columns="n", values="indice", aggfunc="mean", observed=True))
tab("Indice de victoire selon le nombre de Mystiques reçues", pl.pivot_table(index=pl.mystique_held.clip(upper=3), columns="n", values="indice", aggfunc="mean"))

# ---------------------------------------------------------------- paris
h("4. Paris")
tab("Paris exacts (%) : cartes × n (manches normales)", nm.pivot_table(index="cards", columns="n", values="exact", aggfunc="mean"), pct=True)
tab("Paris exacts (%) : cartes × niveau", nm.pivot_table(index="cards", columns="level", values="exact", aggfunc="mean"), pct=True)
tab("Paris exacts (%) : style × niveau", nm.pivot_table(index="style", columns="level", values="exact", aggfunc="mean"), pct=True)
tab("Paris exacts (%) : position de parole × n", nm.pivot_table(index="bet_pos", columns="n", values="exact", aggfunc="mean"), pct=True)
tab("Sens de l'erreur (%) par style : -1 moins de plis que le pari, +1 plus", pd.crosstab(nm["style"], nm["sign"], normalize="index"), pct=True)
tab("Pari moyen / plis moyens / cartes", nm.groupby("cards")[["bet", "tricks"]].mean().assign(somme_paris_sur_cartes=nm.groupby("cards").bet_sum.mean() / nm.groupby("cards").cards.mean()))
last = nm[nm.last_bettor == 1]
tab("Dernier parieur : bloqué par la règle d'or (%) et réussite (%)", last.groupby("cards").agg(
    bloque=("golden_block", "mean"), exact=("exact", "mean"),
    exact_si_bloque=("exact", lambda s: s[last.loc[s.index, "golden_block"] == 1].mean()),
    exact_si_libre=("exact", lambda s: s[last.loc[s.index, "golden_block"] == 0].mean())), pct=True)
tab("Somme des paris − cartes (en %) : la table est-elle « sur-pariante » ?",
    pd.crosstab((nm.drop_duplicates(["game", "round"]).eval("bet_sum - cards")).clip(-4, 4),
                nm.drop_duplicates(["game", "round"]).n, normalize="columns"), pct=True)
cal = nm[nm.p_exact.notna()].copy()
if len(cal):
    cal["bin"] = pd.cut(cal.p_exact, [0, .2, .4, .6, .8, 1.0], include_lowest=True)
    tab("Calibrage : probabilité annoncée par l'IA vs réussite réelle", cal.groupby("bin", observed=True).agg(
        annonce=("p_exact", "mean"), reel=("exact", "mean"), nb=("exact", "size")))
tab("Paris exacts (%) selon le nombre de Pouvoirs en main", nm.pivot_table(index="n_powers", columns="n", values="exact", aggfunc="mean"), pct=True)
tab("Paris exacts (%) selon la Mystique en main", nm.pivot_table(index="has_mystique", columns="cards", values="exact", aggfunc="mean"), pct=True)
tab("Paris exacts (%) selon le classement avant la manche", nm.pivot_table(index=nm.lives_rank_before.clip(upper=4), columns="n", values="exact", aggfunc="mean"), pct=True)
tab("Paris exacts (%) : le donneur vs les autres", nm.pivot_table(index="is_dealer", columns="n", values="exact", aggfunc="mean"), pct=True)

# ---------------------------------------------------------------- vies
h("5. Vies perdues")
tab("Vies perdues par joueur et par manche : cartes × n", nm.pivot_table(index="cards", columns="n", values="lost", aggfunc="mean"))
tab("Taille de l'écart (|plis − pari|) en % des manches", pd.crosstab(nm["cards"], nm["diff"].clip(upper=4), normalize="index"), pct=True)
tab("Pertes moyennes par manche selon le niveau", nm.pivot_table(index="level", columns="cards", values="lost", aggfunc="mean"))

# ---------------------------------------------------------------- mystique (manche à 1 carte)
h("6. Manche Mystique (1 carte sur le front)")
if len(my):
    tab("Manche Mystique : réussite (%) par n et niveau", my.pivot_table(index="level", columns="n", values="exact", aggfunc="mean"), pct=True)
    tab("Manche Mystique : pari 1 (%) et réussite (%) par position", my.groupby("bet_pos").agg(pari1=("bet", "mean"), exact=("exact", "mean")), pct=True)
    tab("Manche Mystique : réussite (%) selon la carte reçue (tranches)",
        my.assign(carte=my.hand.astype(str).str.extract(r"(\w+)")[0]).assign(
            tranche=lambda d: d.carte.map(lambda c: "Mystique" if c == "m" else ("Pouvoir" if c.startswith("p") else
                                                                              pd.cut([int(c[1:])], [0, 9, 18, 27, 36], labels=["1-9", "10-18", "19-27", "28-36"])[0])))
        .groupby("tranche").agg(pari1=("bet", "mean"), exact=("exact", "mean"), nb=("exact", "size")), pct=False)

# ---------------------------------------------------------------- cartes
h("7. Cartes")
pn = p[p.mystic == 0]
card_play = pn.groupby("card").agg(type=("kind", "first"), pouvoir=("power", "first"), valeur=("base_value", "first"),
                                    posee=("won", "size"), pli_gagne=("won", "mean"),
                                    posee_derniere=("is_last", "mean"), forcee=("forced_by", lambda s: s.notna().mean()))
# réussite de manche quand la carte est en main (manches normales hors Mystique)
hold = nm[["game", "round", "seat", "exact", "lost", "hand", "cards", "n", "level"]].copy()
hold["card"] = hold.hand.astype(str).str.split(" ")
hold = hold.explode("card")
# référence : même nombre de cartes, même nombre de joueurs, même niveau (sinon les cartes réservées à 5-6 joueurs sont avantagées)
grp = nm.groupby(["cards", "n", "level"], observed=True)
hold["attendu"] = hold.merge(grp.exact.mean().rename("a").reset_index(), on=["cards", "n", "level"], how="left").a.values
hold["lost_att"] = hold.merge(grp.lost.mean().rename("a").reset_index(), on=["cards", "n", "level"], how="left").a.values
card_hold = hold.groupby("card").agg(en_main=("exact", "size"), reussite_manche=("exact", "mean"),
                                     attendu=("attendu", "mean"), vies_perdues=("lost", "mean"), vies_att=("lost_att", "mean"))
card_hold["effet_reussite_pts"] = (card_hold.reussite_manche - card_hold.attendu) * 100
card_hold["effet_vies"] = card_hold.vies_perdues - card_hold.vies_att
card_hold = card_hold.drop(columns="vies_att")
cards = card_play.join(card_hold, how="outer")
order = cards.assign(o=cards.valeur.fillna(37.5)).sort_values("o").drop(columns="o")
tab("Toutes les cartes : pose, plis gagnés, réussite de manche quand tenue", order)
tab("Pli gagné (%) par tranche de valeur × nombre de cartes en main",
    pn[pn.kind == "number"].assign(tranche=pd.cut(pn.base_value, [0, 6, 12, 18, 24, 30, 36])).pivot_table(
        index="tranche", columns="cards", values="won", aggfunc="mean", observed=True), pct=True)
note("- « Cartes inutiles » : cartes qui ne gagnent presque jamais un pli et ne changent pas la réussite de la manche.")
useless = order[(order.type == "number")].sort_values("effet_reussite_pts").head(8)
useful = order.sort_values("effet_reussite_pts", ascending=False).head(8)
tab("Cartes qui aident le plus à réussir son pari (écart vs moyenne, points)", useful[["type", "valeur", "pli_gagne", "reussite_manche", "effet_reussite_pts"]])
tab("Cartes qui nuisent le plus à la réussite du pari", useless[["type", "valeur", "pli_gagne", "reussite_manche", "effet_reussite_pts"]])
mq = pn[pn.kind == "mystique"]
if len(mq):
    tab("Mystique hors manche Mystique : 0 ou 37 choisi (%) selon le besoin de plis",
        pd.crosstab(mq.need_before.clip(-2, 3), mq.mystic_value, normalize="index"), pct=True)
    note(f"- Mystique jouée en 37 : pli gagné {mq[mq.mystic_value==37].won.mean()*100:.1f} % ; "
         f"en 0 : pli gagné {mq[mq.mystic_value==0].won.mean()*100:.1f} %")

# ---------------------------------------------------------------- pouvoirs
h("8. Pouvoirs")
pw = pn[pn.kind == "power"]
tab("Effet des pouvoirs (%) : appliqué, annulé, sans cible, refusé",
    pd.crosstab(pw.power, pw.effect.fillna("?"), normalize="index"), pct=True)
tab("Effet par pouvoir × position de pose (% appliqué)", pw.assign(ok=(pw.effect == "applique")).pivot_table(
    index="power", columns="pos", values="ok", aggfunc="mean"), pct=True)
tab("Pouvoirs par carte : pli gagné, effet appliqué", pw.groupby("card").agg(
    pouvoir=("power", "first"), valeur=("base_value", "first"), posee=("won", "size"), pli=("won", "mean"),
    applique=("effect", lambda s: (s == "applique").mean())).sort_values(["pouvoir", "valeur"]))
vo = pw[(pw.power == "voile") & (pw.effect == "applique")]
if len(vo):
    note(f"- Voile appliqué : valeur réellement changée dans {vo.swap_changed.mean()*100:.1f} % des cas ; "
         f"pli gagné ensuite {vo.won.mean()*100:.1f} %.")
fc = pn[pn.forced_by.notna()]
if len(fc):
    tab("Cartes forcées (Sceau, Bénédiction) : pli gagné par la victime (%)",
        fc.groupby("forced_by").agg(nb=("won", "size"), pli_gagne=("won", "mean")))
pw_hold = card_hold[card_hold.index.astype(str).str.startswith("p")].copy()
pw_hold["pouvoir"] = pw_hold.index.map(lambda c: cards.loc[c, "pouvoir"])
tab("Réussite de manche quand on tient le pouvoir (points vs moyenne)", pw_hold.groupby("pouvoir").agg(
    en_main=("en_main", "sum"), effet_reussite_pts=("effet_reussite_pts", "mean")))
tab("Pouvoirs appliqués par partie selon n", g.groupby("n").powers_applied.mean().to_frame("pouvoirs_appliqués"))
tg = pw[pw.target_lives_rank.notna() & (pw.effect == "applique")]
if len(tg):
    tab("Qui est visé ? Part des pouvoirs appliqués sur le meneur (rang 1 en Vies), par pouvoir et style (%)",
        tg.assign(meneur=(tg.target_lives_rank == 1)).pivot_table(index="style", columns="power", values="meneur", aggfunc="mean"), pct=True)
cl = pw[(pw.power == "clairvoyance") & (pw.effect == "applique") & pw.peek.notna()]
if len(cl):
    seen = cl.peek.astype(str).map(lambda c: "Mystique" if c == "m" else "Pouvoir" if c.startswith("p") else "Nombre 28-36" if int(c[1:]) >= 28 else "Nombre 1-27")
    tab("Clairvoyance : nature de la carte vue (%)", seen.value_counts(normalize=True).to_frame("part"), pct=True)
    note(f"- Clairvoyance appliquée : pli gagné par celui qui la pose {cl.won.mean()*100:.1f} %.")
if len(vo):
    tab("Voile appliqué : valeur reçue et valeur donnée (moyennes), pli gagné", vo.groupby("card").agg(
        nb=("won", "size"), recue=("swap_got", "mean"), donnee=("swap_gave", "mean"), pli=("won", "mean")))
vict = nm.assign(force=(nm.forced_out > 0).astype(int))
tab("Victime d'un Sceau ou d'une Bénédiction dans la manche : pari exact (%)", vict.pivot_table(index="force", columns="cards", values="exact", aggfunc="mean"), pct=True)
tab("Manche où l'on applique au moins un pouvoir : pari exact (%)", nm.assign(a=(nm.powers_applied > 0).astype(int)).pivot_table(index="a", columns="cards", values="exact", aggfunc="mean"), pct=True)
tab("Quand les pouvoirs sont posés : numéro de pli moyen par style", pn[pn.kind != "number"].pivot_table(index="style", columns="cards", values="trick", aggfunc="mean"))

# ---------------------------------------------------------------- suspense
h("9. Suspense, meneur et remontées")
tab("Suspense par nombre de joueurs", g.groupby("n").agg(
    changements_de_meneur=("lead_changes", "mean"), gagnant_meneur_manche1=("winner_led_r1", "mean"),
    gagnant_meneur_avant_derniere=("winner_led_before_last", "mean"), pire_rang_du_gagnant=("winner_worst_rank", "mean"),
    ecart_max_vies=("max_gap", "mean"), decisions=("decisions", "mean"), coups_au_hasard=("random_plays", "mean")))
tab("Pire classement traversé par le gagnant (en % des parties)", pd.crosstab(g.winner_worst_rank.clip(upper=6), g.n, normalize="columns"), pct=True)
tab("Indice de victoire : meneur (ou co-meneur) après la 1re manche", pl.pivot_table(index="led_r1", columns="n", values="indice", aggfunc="mean"))
rk = normal.merge(pl[["game", "seat", "indice"]], on=["game", "seat"])
tab("Indice de victoire selon le classement après chaque manche (n = 4)",
    rk[(rk.n == 4) & (rk["round"] < 7)].pivot_table(index=rk.rank_after.clip(upper=4), columns="round", values="indice", aggfunc="mean"))
tab("Indice de victoire selon le classement après la manche 3 (4e manche), par n",
    rk[rk["round"] == 3].pivot_table(index="rank_after", columns="n", values="indice", aggfunc="mean"))
tab("Indice de victoire selon le retard en Vies sur le meneur avant la manche",
    rk.pivot_table(index=rk.gap_leader.clip(upper=4), columns="n", values="indice", aggfunc="mean"))
tab("Durée selon le niveau moyen de la table", g.assign(table=pd.cut(g.level_avg, [-0.01, 1.2, 1.8, 2.2, 2.8, 4.01], labels=["très faible", "faible", "moyenne", "forte", "très forte"]))
    .groupby("table", observed=True).agg(parties=("rounds", "size"), manches=("rounds", "mean"), minutes=("est_minutes", "mean"),
                                         changements_de_meneur=("lead_changes", "mean"), marge=("margin", "mean")))

# ---------------------------------------------------------------- mains
h("10. Force de la main et position")
tab("Paris exacts (%) selon le nombre de grosses cartes (28 et plus)", nm.pivot_table(index=nm.n_high.clip(upper=4), columns="cards", values="exact", aggfunc="mean"), pct=True)
tab("Paris exacts (%) selon le nombre de petites cartes (9 et moins)", nm.pivot_table(index=nm.n_low.clip(upper=4), columns="cards", values="exact", aggfunc="mean"), pct=True)
nmq = nm[nm.expected.notna()].copy()
nmq["force"] = nmq.groupby(["cards", "n"]).expected.transform(lambda x: pd.qcut(x.rank(method="first"), 5, labels=False)) + 1
tab("Paris exacts (%) selon la force de la main (1 = très faible … 5 = très forte)", nmq.pivot_table(index="force", columns="cards", values="exact", aggfunc="mean"), pct=True)
tab("Vies perdues par manche selon la force de la main", nmq.pivot_table(index="force", columns="cards", values="lost", aggfunc="mean"))
tab("Pari moins force réelle de la main (en plis), style × niveau", nmq.assign(d=nmq.bet - nmq.expected).pivot_table(index="style", columns="level", values="d", aggfunc="mean", observed=True))
tab("Paris exacts (%) : celui qui entame la manche vs les autres", nm.pivot_table(index="first_lead", columns="n", values="exact", aggfunc="mean"), pct=True)
tab("Paris exacts (%) selon le retard sur le meneur", nm.pivot_table(index=nm.gap_leader.clip(upper=4), columns="n", values="exact", aggfunc="mean"), pct=True)
tab("Pari par carte selon la situation (meneur / milieu / dernier), par style",
    nm.assign(sit=np.where(nm.gap_leader == 0, "1 meneur", np.where(nm.lives_rank_before >= nm.n, "3 dernier", "2 milieu")), ppc=nm.bet / nm.cards)
    .pivot_table(index="style", columns="sit", values="ppc", aggfunc="mean"))
rd = nm.drop_duplicates(["game", "round"]).copy()
rd["tous"] = (rd.others_exact + rd.exact == rd.n).astype(int)
tot = nm.groupby(["game", "round"]).exact.sum().rename("nb_exact").reset_index().merge(rd[["game", "round", "n", "cards"]], on=["game", "round"])
tab("Nombre de joueurs qui réussissent leur pari dans une manche (en %)", pd.crosstab(tot.nb_exact, tot.n, normalize="columns"), pct=True)
tab("Manches où personne ne réussit (%) : cartes × n", tot.assign(z=(tot.nb_exact == 0)).pivot_table(index="cards", columns="n", values="z", aggfunc="mean"), pct=True)
tab("Paris exacts (%) selon les coups au hasard dans la manche, par niveau", nm.assign(h=(nm.random_plays > 0).astype(int)).pivot_table(index="level", columns="h", values="exact", aggfunc="mean", observed=True), pct=True)

# ---------------------------------------------------------------- plis
h("11. Déroulé des plis")
tr = pn.drop_duplicates(["game", "round", "trick"])
tab("Qui gagne le pli ? Position de pose du gagnant (0 = entame), en %", pd.crosstab(tr.win_pos, tr.n, normalize="columns"), pct=True)
tab("Valeur moyenne de la carte gagnante : cartes × n", tr.pivot_table(index="cards", columns="n", values="win_value", aggfunc="mean"))
tab("Cartes spéciales (Pouvoirs, Mystique) dans un même pli (en %)", pd.crosstab(tr.specials_in_trick.clip(upper=4), tr.n, normalize="columns"), pct=True)
tab("Pli gagné (%) selon la position de pose", pn.pivot_table(index="pos", columns="n", values="won", aggfunc="mean"), pct=True)
want = pn.assign(veut=np.where(pn.need_before > 0, "veut le pli", "ne le veut pas"))
tab("Pli gagné (%) selon l'envie du joueur, par niveau", want.pivot_table(index="level", columns="veut", values="won", aggfunc="mean", observed=True), pct=True)
tab("Pli gagné (%) selon l'envie du joueur, par position de pose", want.pivot_table(index="pos", columns="veut", values="won", aggfunc="mean"), pct=True)
tab("Carte posée au hasard (erreur) : part des poses (%) style × niveau", pn.pivot_table(index="style", columns="level", values="random", aggfunc="mean", observed=True), pct=True)
tab("Plis subis (gagnés sans le vouloir) et plis manqués, par carte tenue en dernier (1 carte en main)",
    pn[pn.hand_left == 0].assign(subi=((pn.won == 1) & (pn.need_before <= 0)).astype(int), manque=((pn.won == 0) & (pn.need_before > 0)).astype(int))
    .groupby("cards").agg(subi=("subi", "mean"), manque=("manque", "mean")), pct=True)

(D / "rapport.md").write_text("# Rapport de simulation KYRAN\n\nDossier : " + str(D) + "\n" + "\n".join(out), encoding="utf-8")
with pd.ExcelWriter(D / "tableaux.xlsx") as xw:
    for k, v in sheets.items():
        v.to_excel(xw, sheet_name=k.replace("/", "-").replace(":", "")[:31])
print(f"rapport.md ({len(out)} blocs) et tableaux.xlsx ({len(sheets)} onglets) écrits dans {D}")
