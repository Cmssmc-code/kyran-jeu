"""Compare plusieurs dossiers de résultats (variantes) sur les mêmes indicateurs.
Usage : PYTHONIOENCODING=utf-8 python compare.py resultats/officielle-10000 resultats/variante-* [--max-game 1500]
--max-game : ne garde que les parties 1..N de chaque dossier (mêmes graines = mêmes tables et mêmes donnes au départ)."""
import sys
from pathlib import Path
import pandas as pd

args = sys.argv[1:]
max_game = None
if "--max-game" in args:
    i = args.index("--max-game")
    max_game = int(args[i + 1])
    del args[i:i + 2]
rows = {}
for d in args:
    d = Path(d)
    g = pd.read_csv(d / "games.csv")
    pl = pd.read_csv(d / "players.csv")
    r = pd.read_csv(d / "rounds.csv")
    p = pd.read_csv(d / "plays.csv", usecols=["game", "card", "won", "effect", "mystic"])
    if max_game:
        g, pl, r, p = (x[x.game <= max_game] for x in (g, pl, r, p))
    pl = pl.assign(indice=pl.win_share * pl.n)
    nm = r[(r.tiebreak == 0) & (r.mystic == 0)]
    my = r[(r.tiebreak == 0) & (r.mystic == 1)]
    lvl = pl.groupby("level").indice.mean()
    hold = nm.assign(card=nm.hand.astype(str).str.split(" ")).explode("card")
    base = nm.groupby(["cards", "n", "level"]).lost.mean().rename("b").reset_index()
    hold = hold.merge(base, on=["cards", "n", "level"])
    eff = (hold.lost - hold.b).groupby(hold.card).mean()
    pp = p[p.mystic == 0]
    v = pp[pp.card.isin(["p3", "p34"])]
    rows[d.name] = {
        "parties": len(g),
        "minutes": g.est_minutes.mean(),
        "minutes à 3 joueurs": g[g.n == 3].est_minutes.mean(),
        "minutes à 6 joueurs": g[g.n == 6].est_minutes.mean(),
        "manches": g.rounds.mean(),
        "parties avec départage (%)": (g.tiebreak_rounds > 0).mean() * 100,
        "changements de meneur": g.lead_changes.mean(),
        "marge du gagnant (Vies)": g.margin.mean(),
        "gagnant déjà meneur avant la dernière manche (%)": g.winner_led_before_last.mean() * 100,
        "paris exacts (%)": (nm.lost == 0).mean() * 100,
        "Vies perdues par manche": nm.lost.mean(),
        "manche Mystique réussie (%)": (my.lost == 0).mean() * 100 if len(my) else float("nan"),
        "indice maître": lvl.get("maitre"), "indice confirmé": lvl.get("confirme"), "indice novice": lvl.get("novice"),
        "indice 1re place à parler": pl[pl.seat_rel == 0].indice.mean(),
        "indice dernière place": pl[pl.seat_rel == pl.n - 1].indice.mean(),
        "Voile 3 : pli gagné (%)": v[v.card == "p3"].won.mean() * 100,
        "Voile 34 : pli gagné (%)": v[v.card == "p34"].won.mean() * 100,
        "Voile appliqué (%)": (v.effect == "applique").mean() * 100 if len(v) else float("nan"),
        "Voile 3 : Vies perdues vs moyenne": eff.get("p3"), "Voile 34 : Vies perdues vs moyenne": eff.get("p34"),
        "Mystique : Vies perdues vs moyenne": eff.get("m"),
        "36 : Vies perdues vs moyenne": eff.get("n36"), "1 : Vies perdues vs moyenne": eff.get("n1"),
    }
out = pd.DataFrame(rows).round(3)
print(out.to_markdown())
