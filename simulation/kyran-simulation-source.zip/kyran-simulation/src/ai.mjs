/*
 * Joueurs artificiels (algorithmes, aucune IA de langage).
 *
 * Profil = style × niveau.
 *  Styles : calculateur (neutre), audacieux (parie haut), prudent (parie bas),
 *           imprevisible (coups au hasard de temps en temps), saboteur (cherche aussi à faire
 *           rater les autres).
 *  Niveaux : debutant (règles simples + erreurs), confirme (paris par simulation),
 *            expert (paris, cartes, cibles et valeur de la Mystique par simulation Monte-Carlo).
 *
 * Simulation Monte-Carlo : on redistribue au hasard les cartes que le joueur ne voit pas
 * (en gardant celles qu'il a vues par Clairvoyance), on joue la fin de la manche avec la
 * stratégie simple pour tout le monde, et on garde la décision qui perd le moins de Vies.
 */
import { act, cloneState, makeRng, shuffle, bestPlay, yetToPlay, forbiddenBet, powerOptions } from './engine.mjs';

// bias : pari décalé (en plis) ; chaos : coups au hasard ; sab : poids des Vies perdues par les autres ;
// adapt : prend des risques quand il est dernier, se calme quand il mène ; forget : ne retient pas les
// cartes tombées ; special : > 0 pose ses Pouvoirs et la Mystique dès que possible, < 0 les garde.
const NEUTRAL = { bias: 0, chaos: 0, sab: 0, adapt: 0, forget: 0, special: 0 };
const style = o => ({ ...NEUTRAL, ...o });

export const STYLES = {
  calculateur: style({}),
  audacieux: style({ bias: 0.6 }),
  tete_brulee: style({ bias: 1.2 }),
  prudent: style({ bias: -0.6 }),
  imprevisible: style({ chaos: 0.15 }),
  saboteur: style({ sab: 0.35 }),
  opportuniste: style({ adapt: 0.6 }),
  distrait: style({ forget: 1 }),
  flambeur: style({ special: 1 }),
  econome: style({ special: -1 })
};

// forget : le novice ne compte pas non plus les cartes tombées.
export const LEVELS = {
  novice: { betSims: 0, playSims: 0, mistake: 0.45, betNoise: 0.7, forget: 1 },
  debutant: { betSims: 0, playSims: 0, mistake: 0.2, betNoise: 0.35 },
  confirme: { betSims: 16, playSims: 0, mistake: 0.04, betNoise: 0 },
  expert: { betSims: 32, playSims: 12, mistake: 0, betNoise: 0 },
  maitre: { betSims: 64, playSims: 24, mistake: 0, betNoise: 0 }
};

/** Décalage du pari : fixe, plus l'adaptation au classement (dernier → ose, meneur → assure). */
function biasOf(state, pid, st) {
  if (!st.adapt) return st.bias;
  const lives = state.round.participants.map(id => state.players[id].lives);
  const me = state.players[pid].lives, max = Math.max(...lives), min = Math.min(...lives);
  if (max === min) return st.bias;
  return st.bias + (me === min ? st.adapt : me === max ? -st.adapt / 2 : 0);
}

// ── Ce que voit un joueur ─────────────────────────────────────────────────

/** Cartes que `pid` ne voit pas (ni en main, ni posées ; en manche Mystique : la sienne). */
const SEEN = new Uint32Array(80);
let stamp = 0;
const cidx = c => (c.kind === 'number' ? c.value : c.kind === 'mystique' ? 0 : 40 + c.value);

export function unseenFor(state, pid, forget = 0) {
  const r = state.round;
  const s = ++stamp;
  if (r.mystic) {
    for (const id of r.participants) if (id !== pid) for (const c of state.players[id].hand) SEEN[cidx(c)] = s;
  } else {
    for (const c of state.players[pid].hand) SEEN[cidx(c)] = s;
  }
  if (!forget) for (const c of r.played) SEEN[cidx(c)] = s;
  if (state.trick) for (const p of state.trick.plays) SEEN[cidx(p.card)] = s;
  const out = [];
  for (const c of state.deck) if (SEEN[cidx(c)] !== s) out.push(c);
  return out;
}

/** Une carte inconnue `u` peut-elle battre la valeur `v` (posée par une carte de nature `kind`) ? */
function canBeat(u, v, kind) {
  if (u.kind === 'mystique') return true;
  return u.value > v || (u.value === v && u.kind !== 'number' && kind === 'number');
}

function beatsPlay(v, kind, best) {
  return !best || v > best.value || (v === best.value && kind !== 'number' && best.card.kind === 'number');
}

/** Probabilité qu'aucune de `k` cartes tirées parmi `U` (dont `h` gagnantes) ne batte la nôtre. */
function noneBeats(U, h, k) {
  let p = 1;
  for (let i = 0; i < k; i++) {
    if (U - i <= 0) break;
    p *= Math.max(0, U - h - i) / (U - i);
  }
  return p;
}

/** Options de pose : chaque carte, et la Mystique en 37 ou en 0. */
function playOptions(hand) {
  const out = [];
  for (const c of hand) {
    if (c.kind === 'mystique') {
      out.push({ card: c, v: 37, mv: 37 });
      out.push({ card: c, v: 0, mv: 0 });
    } else out.push({ card: c, v: c.value, mv: undefined });
  }
  return out;
}

function winChance(state, pid, opt, unseen, k) {
  const best = state.trick ? bestPlay(state.trick.plays) : null;
  if (!beatsPlay(opt.v, opt.card.kind, best)) return 0;
  if (opt.v === 0) return 0;
  if (k === 0) return 1;
  let h = 0;
  for (const u of unseen) if (canBeat(u, opt.v, opt.card.kind)) h++;
  return noneBeats(unseen.length, h, k);
}

// ── Stratégie simple (débutant, confirmé en jeu, et toutes les simulations) ──

/** Nombre de plis espéré d'une main (estimation rapide). */
export function handStrength(state, pid) {
  const p = state.players[pid];
  const unseen = unseenFor(state, pid);   // au moment du pari, aucune carte n'est encore tombée
  const m = state.round.participants.length - 1;
  let e = 0;
  for (const c of p.hand) {
    if (c.kind === 'mystique') { e += 0.6; continue; }
    let h = 0;
    for (const u of unseen) if (canBeat(u, c.value, c.kind)) h++;
    e += noneBeats(unseen.length, h, m);
  }
  return e;
}

/** Manche Mystique : probabilité de réussir avec un pari 1 et avec un pari 0. */
export function mysticOdds(state, pid) {
  const r = state.round;
  const pool = unseenFor(state, pid);
  let cases = [{ w: 1, best: null }];
  for (const id of r.participants) {
    if (id === pid) continue;
    const c = state.players[id].hand[0];
    const vals = c.kind !== 'mystique' ? [[c.value, 1]] : state.players[id].bet != null ? [[state.players[id].bet === 1 ? 37 : 0, 1]] : [[37, 0.5], [0, 0.5]];
    const next = [];
    for (const cs of cases) for (const [v, w] of vals) {
      const cand = { value: v, kind: c.kind };
      const b = !cs.best || v > cs.best.value || (v === cs.best.value && c.kind !== 'number' && cs.best.kind === 'number') ? cand : cs.best;
      next.push({ w: cs.w * w, best: b });
    }
    cases = next;
  }
  let p1 = 0, p0 = 0;
  for (const cs of cases) {
    let win = 0, lose = 0;
    for (const u of pool) {
      if (u.kind === 'mystique') { win++; lose++; continue; }
      const b = cs.best;
      const beats = !b || u.value > b.value || (u.value === b.value && u.kind !== 'number' && b.kind === 'number');
      if (beats) win++; else lose++;
    }
    p1 += cs.w * win / pool.length;
    p0 += cs.w * lose / pool.length;
  }
  return { p1, p0 };
}

function pickLegal(state, pid, want) {
  const f = forbiddenBet(state, pid);
  const cards = state.round.cards;
  let b = Math.max(0, Math.min(cards, want));
  if (b !== f) return b;
  const up = b + 1 <= cards ? b + 1 : null;
  const down = b - 1 >= 0 ? b - 1 : null;
  return down == null ? up : up == null ? down : null;
}

export function heuristicBet(state, pid, style = NEUTRAL, rng = Math.random, noise = 0) {
  const r = state.round;
  if (r.mystic) {
    const { p1, p0 } = mysticOdds(state, pid);
    let want = p1 + biasOf(state, pid, style) * 0.15 > p0 ? 1 : 0;
    if (noise && rng() < noise / 2) want = 1 - want;
    const f = forbiddenBet(state, pid);
    const value = want === f ? 1 - want : want;
    return { type: 'bet', pid, value, meta: { expected: p1, wanted: want, pExact: value === 1 ? p1 : p0 } };
  }
  const raw = handStrength(state, pid);
  const e = raw + biasOf(state, pid, style);
  let want = Math.round(e);
  if (noise && rng() < noise) want += rng() < 0.5 ? -1 : 1;
  if (style.chaos && rng() < style.chaos) want += rng() < 0.5 ? -1 : 1;
  want = Math.max(0, Math.min(r.cards, want));
  let value = pickLegal(state, pid, want);
  if (value == null) value = e >= want ? want + 1 : want - 1;
  return { type: 'bet', pid, value, meta: { expected: raw, wanted: want, pExact: null } };
}

export function heuristicPlay(state, pid, style = NEUTRAL) {
  const p = state.players[pid];
  const need = p.bet - p.tricks;
  const left = p.hand.length;
  const unseen = unseenFor(state, pid, style.forget);
  const k = yetToPlay(state, pid).length;
  const opts = playOptions(p.hand).map(o => ({ ...o, w: winChance(state, pid, o, unseen, k) }));
  if (p.peeks.length && !style.forget && !state.round.mystic) {
    // Carte vue par Clairvoyance, encore en main chez un joueur qui doit jouer après nous et qui
    // cherche des plis : si elle bat la nôtre, on ne compte pas sur ce pli.
    const later = yetToPlay(state, pid);
    for (const pk of p.peeks) {
      const t = state.players[pk.target];
      if (!later.includes(pk.target) || t.bet - t.tricks <= 0) continue;
      const card = t.hand.find(c => c.id === pk.id);
      if (card) for (const o of opts) if (o.w > 0 && canBeat(card, o.v, o.card.kind)) o.w = 0;
    }
  }
  let choice;
  if (need > 0) {
    if (need >= left) {
      choice = opts.reduce((a, b) => (b.w > a.w || (b.w === a.w && b.v > a.v) ? b : a));
    } else {
      const sure = opts.filter(o => o.w >= 0.999);
      if (sure.length) choice = sure.reduce((a, b) => (rankKey(b) < rankKey(a) ? b : a));
      else {
        const thr = 0.7 - 0.4 * (need / left);
        const good = opts.filter(o => o.w >= thr);
        if (good.length) choice = good.reduce((a, b) => (rankKey(b) < rankKey(a) ? b : a));
        else choice = dumpLow(opts);
      }
    }
  } else {
    const losers = opts.filter(o => o.w <= 0.001);
    const nonM = losers.filter(o => o.card.kind !== 'mystique');
    if (nonM.length) choice = nonM.reduce((a, b) => (b.v > a.v ? b : a));
    else if (losers.length) choice = losers[0];
    else choice = opts.reduce((a, b) => (b.w < a.w || (b.w === a.w && b.v < a.v) ? b : a));
  }
  if (style.special) {
    // À chance de pli voisine, le flambeur préfère une carte spéciale, l'économe une carte Nombre.
    const wantSp = style.special > 0;
    const isSp = o => o.card.kind !== 'number';
    if (isSp(choice) !== wantSp) {
      const near = opts.filter(o => isSp(o) === wantSp && Math.abs(o.w - choice.w) <= 0.15);
      if (near.length) choice = near.reduce((a, b) => (Math.abs(b.w - choice.w) < Math.abs(a.w - choice.w) ? b : a));
    }
  }
  return { type: 'play', pid, cardId: choice.card.id, mysticValue: choice.mv };
}

// La Mystique est gardée : on la classe comme la plus chère.
const rankKey = o => (o.card.kind === 'mystique' ? 100 : o.v);

function dumpLow(opts) {
  const nonM = opts.filter(o => o.card.kind !== 'mystique');
  if (!nonM.length) return opts.find(o => o.v === 0) || opts[0];
  return nonM.reduce((a, b) => (b.v < a.v ? b : a));
}

export function heuristicTarget(state, pid, pend, style = NEUTRAL, rng = Math.random) {
  const p = state.players[pid];
  const wants = p.bet - p.tricks > 0;
  const need = id => state.players[id].bet - state.players[id].tricks;
  const leader = ids => ids.reduce((a, b) => (state.players[b].lives > state.players[a].lives ? b : a));
  let target;
  if (pend.power === 'voile') {
    const t = state.trick;
    const mine = t.plays.find(x => x.pid === pid);
    const score = (val, swapWith) => {
      const plays = t.plays.map(x => ({ ...x }));
      if (swapWith != null) {
        const a = plays.find(x => x.pid === pid), b = plays.find(x => x.pid === swapWith);
        const tmp = a.value; a.value = b.value; b.value = tmp;
      }
      const best = bestPlay(plays);
      const mineBest = best.pid === pid;
      const v = plays.find(x => x.pid === pid).value;
      return wants ? (mineBest ? 100 : 0) + v : (mineBest ? -100 : 0) - v;
    };
    let bestScore = pend.optional ? score(mine.value, null) : -Infinity;
    target = null;
    for (const id of pend.options) {
      const s = score(null, id);
      if (s > bestScore) { bestScore = s; target = id; }
    }
    return { type: 'target', pid, target };
  }
  if (pend.power === 'clairvoyance') {
    target = style.sab ? leader(pend.options) : pend.options[Math.floor(rng() * pend.options.length)];
  } else if (pend.power === 'benediction' || pend.power === 'sceau') {
    if (wants) target = pend.options.reduce((a, b) => (need(b) > need(a) ? b : a));
    else if (style.sab) target = leader(pend.options);
    else target = pend.options.reduce((a, b) => (need(b) < need(a) ? b : a));
  }
  return { type: 'target', pid, target };
}

export function heuristicMystic(state, pid) {
  const p = state.players[pid];
  return { type: 'mysticValue', pid, value: p.bet - p.tricks > 0 ? 37 : 0 };
}

function heuristicDecide(state, style, rng) {
  const pend = state.pending;
  switch (pend.type) {
    case 'bet': return heuristicBet(state, pend.pid, style, rng);
    case 'play': return heuristicPlay(state, pend.pid);
    case 'target': return heuristicTarget(state, pend.pid, pend, style, rng);
    case 'mysticValue': return heuristicMystic(state, pend.pid);
  }
  throw new Error('Décision inconnue ' + pend.type);
}

// ── Monte-Carlo ───────────────────────────────────────────────────────────

/** Copie où les cartes invisibles pour `pid` sont redistribuées au hasard. */
function determinize(state, pid, seed, forget = 0) {
  const rng = makeRng(seed);
  const c = cloneState(state, seed ^ 0x5bd1e995);
  const r = c.round;
  const seenIds = new Set(r.played.map(x => x.id));
  if (c.trick) for (const pl of c.trick.plays) seenIds.add(pl.card.id);
  const fixed = new Map();
  const fixedIds = new Set();
  if (!r.mystic && !forget) {
    for (const pk of state.players[pid].peeks) {
      if (seenIds.has(pk.id) || fixedIds.has(pk.id)) continue;
      if (!state.players[pk.target].hand.some(x => x.id === pk.id)) continue;
      fixedIds.add(pk.id);
      if (!fixed.has(pk.target)) fixed.set(pk.target, []);
      fixed.get(pk.target).push(pk.id);
    }
  }
  const pool = shuffle(unseenFor(state, pid).filter(x => !fixedIds.has(x.id)), rng);
  const redeal = r.mystic ? [pid] : r.participants.filter(id => id !== pid);
  for (const id of redeal) {
    const size = c.players[id].hand.length;
    const keep = (fixed.get(id) || []).map(cid => state.deck.find(d => d.id === cid)).filter(Boolean);
    const hand = keep.slice(0, size);
    while (hand.length < size) hand.push(pool.pop());
    hand.sort((a, b) => a.rank - b.rank);
    c.players[id].hand = hand;
  }
  return c;
}

function runToRoundEnd(c, rng) {
  let guard = 0;
  while (c.phase !== 'roundEnd') {
    act(c, heuristicDecide(c, NEUTRAL, rng));
    if (++guard > 500) throw new Error('Simulation bloquée');
  }
}

/** Score d'une fin de manche pour `pid` : Vies perdues (négatif), et pour le saboteur Vies des autres. */
function outcome(c, pid, style) {
  const me = c.players[pid];
  let s = -Math.abs(me.bet - me.tricks);
  if (style.sab) {
    let o = 0, n = 0;
    for (const id of c.round.participants) if (id !== pid) { o += Math.abs(c.players[id].bet - c.players[id].tricks); n++; }
    s += style.sab * (n ? o / n : 0);
  }
  return s;
}

/** Évalue des décisions par simulation. Renvoie { scores, exact } (moyennes). */
function evaluate(state, pid, actions, sims, style, seed) {
  const scores = new Array(actions.length).fill(0);
  const exact = new Array(actions.length).fill(0);
  for (let k = 0; k < sims; k++) {
    const base = determinize(state, pid, seed + k * 7919, style.forget);
    for (let i = 0; i < actions.length; i++) {
      // Même donne cachée et même hasard pour toutes les décisions comparées (moins de bruit).
      const c = cloneState(base, seed + k * 104729);
      const rng = makeRng((seed ^ 0x9e3779b9) + k * 40503);
      const a = actions[i];
      if (a.type === 'bet' && a.value === forbiddenBet(c, pid)) c.opts = { ...c.opts, goldenRule: false };
      act(c, a);
      if (a.type === 'bet' && c.opts !== state.opts) c.opts = state.opts;
      runToRoundEnd(c, rng);
      scores[i] += outcome(c, pid, style);
      const me = c.players[pid];
      if (me.bet === me.tricks) exact[i]++;
    }
  }
  return { scores: scores.map(s => s / sims), exact: exact.map(e => e / sims) };
}

// ── Agent ────────────────────────────────────────────────────────────────

export function makeAgent(styleKey, levelKey, seed) {
  const level = LEVELS[levelKey];
  if (!STYLES[styleKey] || !level) throw new Error(`Profil inconnu ${styleKey}:${levelKey}`);
  const style = { ...STYLES[styleKey], forget: STYLES[styleKey].forget || level.forget || 0 };
  const rng = makeRng(seed);
  let calls = 0;
  const nextSeed = () => (seed * 31 + ++calls * 2654435761) >>> 0;

  function bet(state, pid) {
    const r = state.round;
    if (r.mystic || !level.betSims) return heuristicBet(state, pid, style, rng, level.betNoise);
    const all = [];
    for (let b = 0; b <= r.cards; b++) all.push({ type: 'bet', pid, value: b });
    const ev = evaluate(state, pid, all, level.betSims, style, nextSeed());
    const f = forbiddenBet(state, pid);
    const bias = biasOf(state, pid, style);
    const sc = ev.scores.map((s, b) => s + bias * 0.3 * b);
    let wanted = 0;
    for (let b = 1; b < sc.length; b++) if (sc[b] > sc[wanted]) wanted = b;
    let value = -1;
    for (let b = 0; b < sc.length; b++) if (b !== f && (value < 0 || sc[b] > sc[value])) value = b;
    if (style.chaos && rng() < style.chaos) {
      const alt = value + (rng() < 0.5 ? -1 : 1);
      if (alt >= 0 && alt <= r.cards && alt !== f) value = alt;
    }
    return { type: 'bet', pid, value, meta: { expected: handStrength(state, pid), wanted, pExact: ev.exact[value] } };
  }

  function play(state, pid) {
    const p = state.players[pid];
    if (rng() < level.mistake + style.chaos * 0.6) {
      const opts = playOptions(p.hand);
      const o = opts[Math.floor(rng() * opts.length)];
      return { type: 'play', pid, cardId: o.card.id, mysticValue: o.mv, meta: { random: true } };
    }
    const opts = playOptions(p.hand);
    if (!level.playSims || opts.length < 2 || style.forget) return heuristicPlay(state, pid, style);
    const actions = opts.map(o => ({ type: 'play', pid, cardId: o.card.id, mysticValue: o.mv }));
    const ev = evaluate(state, pid, actions, level.playSims, style, nextSeed());
    if (style.special) opts.forEach((o, i) => { if (o.card.kind !== 'number') ev.scores[i] += style.special * 0.08; });
    let best = 0;
    for (let i = 1; i < actions.length; i++) if (ev.scores[i] > ev.scores[best]) best = i;
    return actions[best];
  }

  function target(state, pid, pend) {
    if (rng() < level.mistake + style.chaos) {
      const opts = pend.optional ? [...pend.options, null] : pend.options;
      return { type: 'target', pid, target: opts[Math.floor(rng() * opts.length)] };
    }
    if (!level.playSims || pend.power === 'clairvoyance') return heuristicTarget(state, pid, pend, style, rng);
    const opts = pend.optional ? [null, ...pend.options] : pend.options;
    const actions = opts.map(t => ({ type: 'target', pid, target: t }));
    const ev = evaluate(state, pid, actions, level.playSims, style, nextSeed());
    let best = 0;
    for (let i = 1; i < actions.length; i++) if (ev.scores[i] > ev.scores[best]) best = i;
    return actions[best];
  }

  function mystic(state, pid) {
    if (!level.playSims) return heuristicMystic(state, pid);
    const actions = [37, 0].map(v => ({ type: 'mysticValue', pid, value: v }));
    const ev = evaluate(state, pid, actions, level.playSims, style, nextSeed());
    return ev.scores[0] >= ev.scores[1] ? actions[0] : actions[1];
  }

  return {
    style: styleKey,
    level: levelKey,
    decide(state) {
      const pend = state.pending;
      switch (pend.type) {
        case 'bet': return bet(state, pend.pid);
        case 'play': return play(state, pend.pid);
        case 'target': return target(state, pend.pid, pend);
        case 'mysticValue': return mystic(state, pend.pid);
      }
      throw new Error('Décision inconnue ' + pend.type);
    }
  };
}

export { powerOptions };
