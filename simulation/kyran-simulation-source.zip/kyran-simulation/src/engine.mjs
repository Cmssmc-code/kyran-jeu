/*
 * KYRAN — moteur de règles pour la simulation (sans DOM, sans IA de langage).
 *
 * Règles officielles (regle.html, kyran-jeu.fr) :
 *  - 36 cartes Nombre (1-36), 1 Mystique, cartes Pouvoir : 3-4 joueurs 11, 27, 20, 3 ;
 *    5-6 joueurs les 8 (11/23, 27/4, 20/9, 3/34).
 *  - 5 Vies par joueur. Manches 7 → 6 → 5 → 4 → 3 → 2 → Mystique (1 carte), puis le cycle recommence.
 *  - Donneur qui tourne à chaque manche ; paris à partir de la gauche du donneur ;
 *    règle d'or : la somme des paris ≠ nombre de plis (le dernier ajuste).
 *  - Pli : la plus forte valeur gagne ; égalité Nombre/Pouvoir → le Pouvoir gagne.
 *    Le gagnant entame le pli suivant.
 *  - Pari raté : perte de |pari − plis| Vies.
 *  - Mystique hors manche Mystique : 0 ou 37 au choix au moment de la poser.
 *  - Pouvoirs (activés à la pose, jamais en manche Mystique) :
 *      Clairvoyance (11, 23) : regarder la carte la plus forte d'un joueur.
 *      Sceau du Destin (27, 4) : carte au hasard de la main d'un joueur, jouée immédiatement ;
 *        annulé si on est le dernier à jouer.
 *      Bénédiction des Ancêtres (20, 9) : un joueur joue immédiatement sa carte la plus faible ;
 *        annulé si on est le dernier à jouer.
 *      Voile du Néant (3, 34) : échange (facultatif) de la valeur de sa carte avec une carte déjà
 *        posée par un adversaire ; annulé si on joue en premier.
 *  - Manche Mystique : 1 carte sur le front (on voit celles des autres, pas la sienne), pari 0/1,
 *    révélation simultanée, pouvoirs sans effet, Mystique = 37 si pari 1, 0 sinon. Raté = 1 Vie.
 *  - Fin : dès qu'un joueur n'a plus de Vie (en fin de manche). Le plus de Vies gagne ;
 *    égalité → ultime manche Mystique entre ex æquo.
 *
 * Interprétations (documentées dans README.md) :
 *  - Une carte forcée (Sceau, Bénédiction) compte comme la carte du joueur ciblé pour ce pli ;
 *    si c'est un Pouvoir, il s'active (le joueur ciblé choisit sa cible) ; si c'est la Mystique,
 *    il choisit 0 ou 37.
 *  - La règle d'or s'applique aussi à la manche Mystique (somme des paris ≠ 1).
 *  - Départage : manche Mystique entre ex æquo ; ceux qui réussissent leur pari l'emportent ;
 *    si tous réussissent ou tous échouent, on rejoue (10 fois au plus, puis victoire partagée).
 *    Le départage ne retire pas de Vies (classement final = Vies en fin de partie normale).
 *  - Égalité de valeur après un Voile entre deux cartes de même nature : la première posée gagne.
 *
 * Machine à états : state.pending = décision attendue ({ type, pid, ... }). act(state, action)
 * l'applique. Quand la manche est jouée, state.phase = 'roundEnd' ; finishRound(state) applique
 * les Vies et lance la suite (ou termine). state.log (facultatif) reçoit les événements pour les
 * mesures ; il vaut null dans les simulations internes de l'IA.
 */

export const POWERS = {
  clairvoyance: { name: 'Clairvoyance Antique', values: [11, 23], cancel: null },
  sceau: { name: 'Sceau du Destin', values: [27, 4], cancel: 'last' },
  benediction: { name: 'Bénédiction des Ancêtres', values: [20, 9], cancel: 'last' },
  voile: { name: 'Voile du Néant', values: [3, 34], cancel: 'first' }
};

export const DEFAULT_ROUNDS = [7, 6, 5, 4, 3, 2, 1];

// Cartes immuables, partagées par toutes les parties.
export const CARDS = {};
for (let v = 1; v <= 36; v++) CARDS['n' + v] = Object.freeze({ id: 'n' + v, kind: 'number', value: v, rank: v });
CARDS.m = Object.freeze({ id: 'm', kind: 'mystique', value: 37, rank: 37.5 });
for (const [key, def] of Object.entries(POWERS)) {
  for (const v of def.values) CARDS['p' + v] = Object.freeze({ id: 'p' + v, kind: 'power', power: key, value: v, rank: v + 0.5 });
}

export function buildDeck(n, { powers = true, mystique = true } = {}) {
  const deck = [];
  for (let v = 1; v <= 36; v++) deck.push(CARDS['n' + v]);
  if (mystique) deck.push(CARDS.m);
  if (powers) {
    for (const def of Object.values(POWERS)) {
      const values = n >= 5 ? def.values : [def.values[0]];
      for (const v of values) deck.push(CARDS['p' + v]);
    }
  }
  return deck;
}

export function makeRng(seed) {
  let a = (seed >>> 0) || 0x9e3779b9;
  return function rng() {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export function shuffle(arr, rng) {
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    const t = arr[i]; arr[i] = arr[j]; arr[j] = t;
  }
  return arr;
}

/**
 * opts : { n, seed, dealer?, lives=5, rounds=[7..1], powers=true, mystique=true, goldenRule=true,
 *          maxRounds=400, maxTiebreaks=10 }
 */
export function createGame(opts) {
  const o = { lives: 5, rounds: DEFAULT_ROUNDS, powers: true, mystique: true, goldenRule: true, maxRounds: 400, maxTiebreaks: 10, ...opts };
  const n = o.n;
  if (n < 3 || n > 6) throw new Error('3 à 6 joueurs');
  const deck = buildDeck(n, o);
  const maxCards = Math.floor(deck.length / n);
  const rounds = o.rounds.filter(c => c <= maxCards);
  const rng = makeRng(o.seed);
  return {
    opts: o,
    n,
    rounds,
    deck,
    rng,
    // Hasard du Sceau, séparé du hasard des donnes : à graine égale, les mains distribuées sont les
    // mêmes quels que soient les choix des joueurs (comparaisons à hasard commun).
    fx: makeRng((o.seed ^ 0x2545f491) >>> 0),
    players: Array.from({ length: n }, (_, i) => ({ id: i, lives: o.lives, hand: [], bet: null, tricks: 0, peeks: [] })),
    roundNo: -1,
    dealer: o.dealer != null ? o.dealer : Math.floor(rng() * n),
    phase: 'idle',
    pending: null,
    round: null,
    trick: null,
    tiebreak: null,
    tiebreakCount: 0,
    winners: null,
    over: false,
    log: null
  };
}

function orderAfter(n, from, ids) {
  const out = [];
  for (let k = 1; k <= n; k++) {
    const id = (from + k) % n;
    if (ids.includes(id)) out.push(id);
  }
  return out;
}

function orderFrom(n, leader, ids) {
  const out = [];
  for (let k = 0; k < n; k++) {
    const id = (leader + k) % n;
    if (ids.includes(id)) out.push(id);
  }
  return out;
}

export function startRound(state) {
  const n = state.n;
  const all = state.players.map(p => p.id);
  const participants = state.tiebreak ? state.tiebreak.slice() : all;
  state.roundNo++;
  if (state.roundNo > 0) state.dealer = (state.dealer + 1) % n;
  const cards = state.tiebreak ? 1 : state.rounds[state.roundNo % state.rounds.length];
  const deck = shuffle(state.deck.slice(), state.rng);
  for (const p of state.players) {
    p.hand = [];
    p.bet = null;
    p.tricks = 0;
    p.peeks = [];
  }
  // Distribution une carte à la fois en partant de la gauche du donneur (comme à la table).
  const dealOrder = orderAfter(n, state.dealer, participants);
  for (let c = 0; c < cards; c++) for (const pid of dealOrder) state.players[pid].hand.push(deck.pop());
  for (const pid of participants) state.players[pid].hand.sort((a, b) => a.rank - b.rank);
  state.round = {
    no: state.roundNo,
    cards,
    mystic: cards === 1,
    tiebreak: !!state.tiebreak,
    participants,
    dealer: state.dealer,
    betOrder: dealOrder,
    betIdx: 0,
    trickNo: 0,
    played: []
  };
  state.trick = null;
  state.phase = 'bet';
  state.pending = { type: 'bet', pid: dealOrder[0] };
  if (state.log) state.log.roundStart(state);
}

export function legalBets(state, pid) {
  const r = state.round;
  const out = [];
  for (let b = 0; b <= r.cards; b++) out.push(b);
  const f = forbiddenBet(state, pid);
  return f == null ? out : out.filter(b => b !== f);
}

/** Pari interdit par la règle d'or pour `pid` (null s'il n'est pas le dernier à parier). */
export function forbiddenBet(state, pid) {
  const r = state.round;
  if (!state.opts.goldenRule || r.betOrder.length < 2 || r.betOrder[r.betOrder.length - 1] !== pid) return null;
  let sum = 0;
  for (const id of r.betOrder) if (id !== pid) sum += state.players[id].bet;
  const f = r.cards - sum;
  return f >= 0 && f <= r.cards ? f : null;
}

function startTrick(state, leader) {
  const r = state.round;
  r.trickNo++;
  state.trick = { no: r.trickNo, leader, order: orderFrom(state.n, leader, r.participants), plays: [] };
  advance(state);
}

function hasPlayed(trick, pid) {
  for (const p of trick.plays) if (p.pid === pid) return true;
  return false;
}

export function yetToPlay(state, exceptPid) {
  const t = state.trick;
  if (!t) return [];
  return t.order.filter(id => id !== exceptPid && !hasPlayed(t, id));
}

function advance(state) {
  const t = state.trick;
  for (const id of t.order) {
    if (!hasPlayed(t, id)) {
      state.pending = { type: 'play', pid: id };
      return;
    }
  }
  resolveTrick(state);
}

/** Meilleure pose : valeur, puis Pouvoir/Mystique sur Nombre à égalité, puis la première posée. */
export function bestPlay(plays) {
  let best = null;
  for (const p of plays) {
    if (p.value == null) continue;
    if (!best || p.value > best.value || (p.value === best.value && p.card.kind !== 'number' && best.card.kind === 'number')) best = p;
  }
  return best;
}

function resolveTrick(state) {
  const r = state.round;
  const t = state.trick;
  const win = bestPlay(t.plays);
  state.players[win.pid].tricks++;
  for (const p of t.plays) r.played.push(p.card);
  if (state.log) state.log.trick(state, t, win);
  state.pending = null;
  if (state.players[r.participants[0]].hand.length > 0) startTrick(state, win.pid);
  else {
    state.trick = null;
    state.phase = 'roundEnd';
  }
}

function placeCard(state, pid, card, forcedBy, mysticValue) {
  const t = state.trick;
  const play = { pid, card, value: card.kind === 'mystique' ? null : card.value, forcedBy: forcedBy || null, pos: t.plays.length, effect: null, target: null, mysticValue: null };
  t.plays.push(play);
  if (card.kind === 'mystique') {
    if (mysticValue === 0 || mysticValue === 37) return setMysticValue(state, play, mysticValue);
    state.pending = { type: 'mysticValue', pid };
    return;
  }
  afterPlace(state, play);
}

function setMysticValue(state, play, value) {
  play.value = value;
  play.mysticValue = value;
  afterPlace(state, play);
}

/** Cibles possibles d'un pouvoir (null = effet annulé par la règle). */
export function powerOptions(state, pid, power) {
  const def = POWERS[power];
  const t = state.trick;
  const toPlay = yetToPlay(state, pid);
  if (def.cancel === 'last' && toPlay.length === 0) return null;
  if (def.cancel === 'first' && t.plays.length <= 1) return null;
  if (power === 'sceau' || power === 'benediction') return toPlay;
  if (power === 'clairvoyance') return state.round.participants.filter(id => id !== pid && state.players[id].hand.length > 0);
  return t.plays.filter(p => p.pid !== pid).map(p => p.pid);
}

function afterPlace(state, play) {
  if (play.card.kind === 'power' && !state.round.mystic) {
    const power = play.card.power;
    const options = powerOptions(state, play.pid, power);
    if (options === null) play.effect = 'annule';
    else if (options.length === 0) play.effect = 'sans_cible';
    else {
      state.pending = { type: 'target', pid: play.pid, power, options, optional: power === 'voile' && !state.opts.voileForced };
      return;
    }
  }
  if (state.log) state.log.play(state, play);
  advance(state);
}

function applyTarget(state, pid, power, target) {
  const t = state.trick;
  const mine = t.plays.find(p => p.pid === pid);
  mine.target = target;
  if (power === 'voile') {
    if (target == null) {
      mine.effect = 'refuse';
    } else {
      const theirs = t.plays.find(p => p.pid === target);
      const before = bestPlay(t.plays).pid;
      const a = mine.value;
      mine.value = theirs.value;
      theirs.value = a;
      mine.effect = 'applique';
      mine.swap = { before, after: bestPlay(t.plays).pid, got: mine.value, gave: a };
    }
    if (state.log) state.log.play(state, mine);
    return advance(state);
  }
  const victim = state.players[target];
  if (power === 'clairvoyance') {
    let best = victim.hand[0];
    for (const c of victim.hand) if (c.rank > best.rank) best = c;
    state.players[pid].peeks.push({ target, id: best.id });
    mine.effect = 'applique';
    mine.peek = best.id;
    if (state.log) state.log.play(state, mine);
    return advance(state);
  }
  let idx = 0;
  if (power === 'sceau') idx = Math.floor(state.fx() * victim.hand.length);
  else victim.hand.forEach((c, i) => { if (c.rank < victim.hand[idx].rank) idx = i; });
  const card = victim.hand.splice(idx, 1)[0];
  mine.effect = 'applique';
  mine.forcedCard = card.id;
  if (state.log) state.log.play(state, mine);
  placeCard(state, target, card, power);
}

function reveal(state) {
  const r = state.round;
  state.trick = { no: 1, leader: r.betOrder[0], order: r.betOrder.slice(), plays: [] };
  r.trickNo = 1;
  for (const pid of r.betOrder) {
    const p = state.players[pid];
    const card = p.hand.pop();
    const value = card.kind === 'mystique' ? (p.bet === 1 ? 37 : 0) : card.value;
    const play = { pid, card, value, forcedBy: null, pos: state.trick.plays.length, effect: card.kind === 'power' ? 'mystique_inactif' : null, target: null, mysticValue: card.kind === 'mystique' ? value : null };
    state.trick.plays.push(play);
    if (state.log) state.log.play(state, play);
  }
  resolveTrick(state);
}

/** Applique une décision. action : {type:'bet',pid,value} | {type:'play',pid,cardId,mysticValue?} |
 *  {type:'mysticValue',pid,value} | {type:'target',pid,target}. */
export function act(state, action) {
  const pend = state.pending;
  if (!pend || pend.type !== action.type || pend.pid !== action.pid) throw new Error(`Action inattendue ${action.type}/${action.pid} (attendu ${pend && pend.type}/${pend && pend.pid})`);
  state.pending = null;
  switch (action.type) {
    case 'bet': {
      const r = state.round;
      if (action.value === forbiddenBet(state, action.pid) || action.value < 0 || action.value > r.cards) throw new Error('Pari interdit ' + action.value);
      state.players[action.pid].bet = action.value;
      if (state.log) state.log.bet(state, action);
      r.betIdx++;
      if (r.betIdx < r.betOrder.length) state.pending = { type: 'bet', pid: r.betOrder[r.betIdx] };
      else {
        state.phase = 'play';
        if (r.mystic) reveal(state);
        else startTrick(state, r.betOrder[0]);
      }
      return;
    }
    case 'play': {
      const p = state.players[action.pid];
      const idx = p.hand.findIndex(c => c.id === action.cardId);
      if (idx < 0) throw new Error('Carte absente ' + action.cardId);
      const card = p.hand.splice(idx, 1)[0];
      return placeCard(state, action.pid, card, null, action.mysticValue);
    }
    case 'mysticValue': {
      if (action.value !== 0 && action.value !== 37) throw new Error('Mystique 0 ou 37');
      const play = state.trick.plays.find(p => p.pid === action.pid);
      return setMysticValue(state, play, action.value);
    }
    case 'target': {
      if (!(pend.options.includes(action.target) || (pend.optional && action.target == null))) throw new Error('Cible invalide');
      return applyTarget(state, action.pid, pend.power, action.target);
    }
    default:
      throw new Error('Action inconnue ' + action.type);
  }
}

/** Fin de manche : Vies, fin de partie, départage. Renvoie les résultats de la manche. */
export function finishRound(state) {
  const r = state.round;
  const results = r.participants.map(id => {
    const p = state.players[id];
    const diff = Math.abs(p.bet - p.tricks);
    const before = p.lives;
    const lost = r.tiebreak ? 0 : Math.min(diff, p.lives);
    p.lives -= lost;
    return { pid: id, bet: p.bet, tricks: p.tricks, diff, lost, before, after: p.lives };
  });
  if (state.log) state.log.roundEnd(state, results);
  const ids = state.players.map(p => p.id);
  let tied = null;
  if (r.tiebreak) {
    const pool = state.tiebreak;
    const ok = results.filter(x => x.diff === 0).map(x => x.pid);
    tied = ok.length && ok.length < pool.length ? ok : pool;
    state.tiebreakCount++;
  } else if (ids.some(id => state.players[id].lives <= 0) || state.roundNo + 1 >= state.opts.maxRounds) {
    const max = Math.max(...ids.map(id => state.players[id].lives));
    tied = ids.filter(id => state.players[id].lives === max);
  } else {
    startRound(state);
    return results;
  }
  if (tied.length > 1 && state.tiebreakCount < state.opts.maxTiebreaks) {
    state.tiebreak = tied;
    startRound(state);
    return results;
  }
  state.winners = tied;
  state.tiebreak = null;
  state.over = true;
  state.phase = 'over';
  state.pending = null;
  if (state.log) state.log.gameEnd(state);
  return results;
}

/** Copie légère pour les simulations de l'IA (cartes partagées, mains copiées, sans journal). */
export function cloneState(state, seed) {
  const r = state.round;
  return {
    opts: state.opts,
    n: state.n,
    rounds: state.rounds,
    deck: state.deck,
    rng: makeRng(seed),
    fx: makeRng((seed ^ 0x2545f491) >>> 0),
    players: state.players.map(p => ({ id: p.id, lives: p.lives, hand: p.hand.slice(), bet: p.bet, tricks: p.tricks, peeks: p.peeks.slice() })),
    roundNo: state.roundNo,
    dealer: state.dealer,
    phase: state.phase,
    pending: state.pending && { ...state.pending },
    round: r && { ...r, played: r.played.slice() },
    trick: state.trick && { ...state.trick, plays: state.trick.plays.map(p => ({ ...p })) },
    tiebreak: state.tiebreak,
    tiebreakCount: state.tiebreakCount,
    winners: null,
    over: false,
    log: null
  };
}
