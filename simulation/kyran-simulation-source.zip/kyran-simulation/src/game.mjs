/*
 * Une partie complète, de la première distribution à la victoire, avec journal des mesures.
 */
import { createGame, startRound, act, finishRound, POWERS } from './engine.mjs';
import { makeAgent, handStrength, LEVELS } from './ai.mjs';

export const TABLES = {
  games: ['game', 'seed', 'variant', 'n', 'first_dealer', 'rounds', 'full_cycles', 'last_cards', 'tiebreak_rounds', 'winners', 'n_winners', 'eliminated', 'lives_end', 'margin', 'est_minutes', 'tricks_total', 'powers_applied', 'profiles', 'ms', 'lead_changes', 'winner_worst_rank', 'winner_led_r1', 'winner_led_before_last', 'max_gap', 'decisions', 'random_plays', 'level_avg'],
  players: ['game', 'variant', 'n', 'seat', 'seat_rel', 'style', 'level', 'profile', 'final_lives', 'rank', 'win', 'win_share', 'eliminated', 'rounds_exact', 'rounds_played', 'lives_lost', 'tricks', 'powers_played', 'mystique_held', 'worst_rank', 'led_r1', 'rounds_led', 'random_plays', 'forced_out', 'powers_applied', 'tricks_led', 'opp_level'],
  rounds: ['game', 'variant', 'n', 'round', 'cycle', 'cards', 'mystic', 'tiebreak', 'seat', 'seat_rel', 'style', 'level', 'bet_pos', 'is_dealer', 'last_bettor', 'forbidden', 'golden_block', 'bet', 'wanted', 'expected', 'p_exact', 'tricks', 'diff', 'sign', 'lost', 'lives_before', 'lives_after', 'has_mystique', 'n_powers', 'hand', 'bet_sum', 'lives_rank_before', 'gap_leader', 'rank_after', 'hand_max', 'hand_min', 'hand_sum', 'n_high', 'n_low', 'tricks_led', 'first_lead', 'random_plays', 'forced_out', 'powers_applied', 'bets_before_sum', 'others_exact'],
  plays: ['game', 'variant', 'n', 'round', 'cards', 'mystic', 'trick', 'seat', 'style', 'level', 'card', 'kind', 'power', 'base_value', 'final_value', 'mystic_value', 'pos', 'is_last', 'forced_by', 'effect', 'target', 'forced_card', 'swap_changed', 'won', 'need_before', 'hand_left', 'lead_seat', 'win_seat', 'win_value', 'win_pos', 'peek', 'swap_got', 'swap_gave', 'random', 'bet', 'tricks_before', 'lives', 'target_lives_rank', 'specials_in_trick']
};

const PROFILE_SEP = '|';
const LEVEL_KEYS = Object.keys(LEVELS);
const cardVal = c => (c.kind === 'mystique' ? 37 : c.value);

class Recorder {
  constructor(meta) {
    this.meta = meta;
    this.rows = { games: [], players: [], rounds: [], plays: [] };
    this.roundBets = new Map();
    this.agg = meta.profiles.map(() => ({ exact: 0, rounds: 0, lost: 0, tricks: 0, powers: 0, mystique: 0, worst: 1, ledR1: 0, roundsLed: 0, random: 0, forcedOut: 0, applied: 0, led: 0 }));
    this.random = new Set();      // cartes posées au hasard (erreur ou style) dans la manche en cours
    this.decisions = 0;
    this.leadChanges = 0;
    this.leaders = null;
    this.maxGap = 0;
    this.ledBeforeLast = [];
    this.est = 0;
    this.tricksTotal = 0;
    this.powersApplied = 0;
    this.normalRounds = 0;
    this.tiebreakRounds = 0;
    this.lastCards = null;
  }
  rel(seat) {
    const n = this.meta.n;
    return (seat - this.meta.firstDealer - 1 + 2 * n) % n;
  }
  roundStart(state) {
    const r = state.round;
    this.roundBets.clear();
    this.random.clear();
    this.rc = state.players.map(() => ({ led: 0, random: 0, forcedOut: 0, applied: 0 }));
    this.handsAtDeal = new Map(r.participants.map(id => [id, state.players[id].hand.slice()]));
    this.strength = new Map(r.participants.map(id => [id, r.mystic ? null : handStrength(state, id)]));
    this.livesBefore = state.players.map(p => p.lives);
    if (r.tiebreak) this.tiebreakRounds++;
    else { this.normalRounds++; this.lastCards = r.cards; }
    const n = r.participants.length;
    this.est += r.mystic ? 25 + 6 * n + 8 : 30 + 6 * n + 4 * n * r.cards + 3 * r.cards;
  }
  bet(state, action) {
    const r = state.round;
    let before = 0;
    for (const id of r.betOrder.slice(0, r.betIdx)) before += state.players[id].bet;
    this.roundBets.set(action.pid, { meta: action.meta || {}, before });
  }
  play() {}
  trick(state, t, win) {
    const r = state.round;
    this.tricksTotal++;
    const m = this.meta;
    const lb = this.livesBefore;
    const specials = t.plays.filter(p => p.card.kind !== 'number').length;
    if (!r.mystic) this.rc[t.leader].led++;
    for (const p of t.plays) {
      const rnd = this.random.has(p.card.id) && !p.forcedBy;
      const c = this.rc[p.pid];
      if (rnd) c.random++;
      if (p.forcedBy) c.forcedOut++;
      if (p.effect === 'applique') c.applied++;
      const pl = state.players[p.pid];
      const prof = m.profiles[p.pid];
      if (p.card.kind === 'power' && !r.mystic) this.agg[p.pid].powers++;
      if (p.effect === 'applique') this.powersApplied++;
      const needBefore = pl.bet - pl.tricks + (p.pid === win.pid ? 1 : 0);
      this.rows.plays.push([
        m.game, m.variant, m.n, r.no, r.cards, +r.mystic, t.no, p.pid, prof.style, prof.level, p.card.id, p.card.kind,
        p.card.power || '', p.card.kind === 'mystique' ? '' : p.card.value, p.value, p.mysticValue ?? '', p.pos, +(p.pos === t.plays.length - 1),
        p.forcedBy || '', p.effect || '', p.target ?? '', p.forcedCard || '', p.swap ? +(p.swap.before !== p.swap.after) : '',
        +(p.pid === win.pid), needBefore, pl.hand.length,
        t.leader, win.pid, win.value, win.pos, p.peek || '', p.swap ? p.swap.got : '', p.swap ? p.swap.gave : '', +rnd, pl.bet,
        pl.tricks - (p.pid === win.pid ? 1 : 0), lb[p.pid], p.target != null ? 1 + lb.filter(l => l > lb[p.target]).length : '', specials
      ]);
    }
  }
  roundEnd(state, results) {
    const r = state.round;
    const m = this.meta;
    const betSum = results.reduce((s, x) => s + x.bet, 0);
    const lb = this.livesBefore;
    const la = state.players.map(p => p.lives);
    const maxBefore = Math.max(...r.participants.map(id => lb[id]));
    const exactCount = results.filter(x => x.diff === 0).length;
    const last = r.betOrder[r.betOrder.length - 1];
    let forbidden = null;
    if (state.opts.goldenRule && r.betOrder.length > 1) {
      const others = betSum - state.players[last].bet;
      const f = r.cards - others;
      if (f >= 0 && f <= r.cards) forbidden = f;
    }
    for (const x of results) {
      const prof = m.profiles[x.pid];
      const hand = this.handsAtDeal.get(x.pid);
      const info = this.roundBets.get(x.pid) || { meta: {} };
      const isLast = x.pid === last;
      const rankBefore = 1 + lb.filter(l => l > lb[x.pid]).length;
      const a = this.agg[x.pid];
      if (!r.tiebreak) {
        a.rounds++;
        if (x.diff === 0) a.exact++;
        a.lost += x.lost;
        a.tricks += x.tricks;
        if (hand.some(c => c.kind === 'mystique')) a.mystique++;
      }
      const rc = this.rc[x.pid];
      if (!r.tiebreak) { a.random += rc.random; a.forcedOut += rc.forcedOut; a.applied += rc.applied; a.led += rc.led; }
      const vals = hand.map(cardVal);
      const wanted = info.meta.wanted;
      this.rows.rounds.push([
        m.game, m.variant, m.n, r.no, Math.floor(r.no / state.rounds.length), r.cards, +r.mystic, +r.tiebreak, x.pid, this.rel(x.pid),
        prof.style, prof.level, r.betOrder.indexOf(x.pid), +(x.pid === r.dealer), +isLast, isLast && forbidden != null ? forbidden : '',
        isLast && forbidden != null && wanted === forbidden ? 1 : 0, x.bet, wanted ?? '',
        info.meta.expected != null ? info.meta.expected.toFixed(3) : (this.strength.get(x.pid) ?? '') === '' ? '' : this.strength.get(x.pid).toFixed(3),
        info.meta.pExact != null ? info.meta.pExact.toFixed(3) : '', x.tricks, x.diff, Math.sign(x.tricks - x.bet), x.lost, x.before, x.after,
        +hand.some(c => c.kind === 'mystique'), hand.filter(c => c.kind === 'power').length, hand.map(c => c.id).join(' '), betSum, rankBefore,
        maxBefore - x.before, 1 + la.filter(l => l > x.after).length, Math.max(...vals), Math.min(...vals), vals.reduce((s, v) => s + v, 0),
        vals.filter(v => v >= 28).length, vals.filter(v => v <= 9).length, rc.led, +(x.pid === r.betOrder[0]), rc.random, rc.forcedOut, rc.applied,
        info.before ?? '', exactCount - (x.diff === 0 ? 1 : 0)
      ]);
    }
    if (!r.tiebreak) {
      // Suivi du meneur après chaque manche normale.
      const max = Math.max(...la), min = Math.min(...la);
      const key = la.map((l, i) => (l === max ? i : -1)).filter(i => i >= 0).join(PROFILE_SEP);
      if (this.leaders != null && key !== this.leaders) this.leadChanges++;
      this.leaders = key;
      this.maxGap = Math.max(this.maxGap, max - min);
      const maxLb = Math.max(...lb);
      this.ledBeforeLast = lb.map(l => +(l === maxLb));
      la.forEach((l, i) => {
        const a = this.agg[i];
        const rank = 1 + la.filter(v => v > l).length;
        a.worst = Math.max(a.worst, rank);
        if (rank === 1) a.roundsLed++;
        if (this.normalRounds === 1 && rank === 1) a.ledR1 = 1;
      });
    }
  }
  gameEnd(state) {
    const m = this.meta;
    const n = m.n;
    const lives = state.players.map(p => p.lives);
    const winners = state.winners;
    const sorted = lives.slice().sort((a, b) => b - a);
    const margin = sorted[0] - (sorted[1] ?? 0);
    const elim = state.players.filter(p => p.lives <= 0).map(p => p.id);
    this.rows.games.push([
      m.game, m.seed, m.variant, n, m.firstDealer, this.normalRounds, Math.floor(this.normalRounds / state.rounds.length), this.lastCards,
      this.tiebreakRounds, winners.join(PROFILE_SEP), winners.length, elim.join(PROFILE_SEP), lives.join(PROFILE_SEP), margin,
      (this.est / 60).toFixed(1), this.tricksTotal, this.powersApplied, m.profiles.map(p => p.style + ':' + p.level).join(PROFILE_SEP), 0,
      this.leadChanges, Math.max(...winners.map(w => this.agg[w].worst)), +winners.some(w => this.agg[w].ledR1), +winners.some(w => this.ledBeforeLast[w]),
      this.maxGap, this.decisions, this.agg.reduce((s, a) => s + a.random, 0),
      (m.profiles.reduce((s, p) => s + LEVEL_KEYS.indexOf(p.level), 0) / n).toFixed(2)
    ]);
    for (const p of state.players) {
      const prof = m.profiles[p.id];
      const a = this.agg[p.id];
      const rank = 1 + lives.filter(l => l > p.lives).length;
      const win = winners.includes(p.id);
      this.rows.players.push([
        m.game, m.variant, n, p.id, this.rel(p.id), prof.style, prof.level, prof.style + ':' + prof.level, p.lives, win ? 1 : Math.max(2, rank),
        +win, win ? (1 / winners.length).toFixed(4) : 0, +(p.lives <= 0), a.exact, a.rounds, a.lost, a.tricks, a.powers, a.mystique,
        a.worst, a.ledR1, a.roundsLed, a.random, a.forcedOut, a.applied, a.led,
        (m.profiles.reduce((s, q, i) => s + (i === p.id ? 0 : LEVEL_KEYS.indexOf(q.level)), 0) / (n - 1)).toFixed(2)
      ]);
    }
  }
}

/**
 * spec : { game, seed, n, variant, profiles:[{style,level}], opts:{} }
 * Renvoie les lignes des tables.
 */
export function playGame(spec) {
  const t0 = Date.now();
  const state = createGame({ n: spec.n, seed: spec.seed, ...spec.opts });
  const rec = new Recorder({ game: spec.game, seed: spec.seed, n: spec.n, variant: spec.variant, profiles: spec.profiles, firstDealer: state.dealer });
  state.log = rec;
  const agents = spec.profiles.map((p, i) => makeAgent(p.style, p.level, (spec.seed ^ (i + 1) * 0x9e3779b1) >>> 0));
  startRound(state);
  let guard = 0;
  while (!state.over) {
    if (state.phase === 'roundEnd') {
      checkRound(state);
      finishRound(state);
    } else {
      const a = agents[state.pending.pid].decide(state);
      rec.decisions++;
      if (a.type === 'play' && a.meta && a.meta.random) rec.random.add(a.cardId);
      act(state, a);
    }
    if (++guard > 200000) throw new Error('Partie bloquée ' + spec.game);
  }
  for (const [k, head] of Object.entries(TABLES)) for (const row of rec.rows[k]) if (row.length !== head.length) throw new Error(`Table ${k} : ${row.length} colonnes au lieu de ${head.length}`);
  const g = rec.rows.games[0];
  g[TABLES.games.indexOf('ms')] = Date.now() - t0;
  return rec.rows;
}

/** Contrôles d'intégrité de fin de manche (lèvent une erreur si une règle est violée). */
function checkRound(state) {
  const r = state.round;
  const ids = r.participants;
  let tricks = 0, bets = 0;
  for (const id of ids) {
    const p = state.players[id];
    if (p.hand.length) throw new Error('Main non vide en fin de manche');
    tricks += p.tricks;
    bets += p.bet;
    if (p.bet < 0 || p.bet > r.cards) throw new Error('Pari hors bornes');
  }
  if (tricks !== r.cards) throw new Error(`Plis ${tricks} ≠ cartes ${r.cards}`);
  if (r.played.length !== r.cards * ids.length) throw new Error('Cartes jouées incohérentes');
  if (new Set(r.played.map(c => c.id)).size !== r.played.length) throw new Error('Carte jouée deux fois');
  if (state.opts.goldenRule && ids.length > 1 && bets === r.cards) throw new Error("Règle d'or violée");
}

export { POWERS };
