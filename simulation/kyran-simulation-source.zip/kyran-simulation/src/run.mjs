/*
 * Lance N parties en parallèle (worker_threads) et écrit les tables CSV.
 *
 *   node src/run.mjs --games 10000 [--seed 1] [--workers 11] [--out resultats/nom]
 *                    [--variant officielle|sans_pouvoirs|sans_mystique|sans_regle_or|vies3|vies7|voile_obligatoire|mix]
 *                    [--levels debutant,confirme,expert] [--styles calculateur,...]
 *
 * Chaque partie : 3 à 6 joueurs (répartis à parts égales), un style et un niveau tirés au hasard
 * pour chaque siège, une graine propre (la partie est rejouable à l'identique).
 */
import { Worker, isMainThread, parentPort, workerData } from 'node:worker_threads';
import { mkdirSync, appendFileSync, writeFileSync, readFileSync, existsSync, rmSync, readdirSync } from 'node:fs';
import { join, resolve } from 'node:path';
import { cpus } from 'node:os';
import { fileURLToPath } from 'node:url';
import { makeRng } from './engine.mjs';
import { STYLES, LEVELS } from './ai.mjs';

export const VARIANTS = {
  officielle: {},
  sans_pouvoirs: { powers: false },
  sans_mystique: { mystique: false },
  sans_regle_or: { goldenRule: false },
  vies3: { lives: 3 },
  vies7: { lives: 7 },
  voile_obligatoire: { voileForced: true }
};

function csvLine(row) {
  return row.map(v => {
    const s = String(v);
    return /[",\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
  }).join(',') + '\n';
}

export function makeSpecs({ games, seed, variant, styles, levels }) {
  const specs = [];
  const variantKeys = Object.keys(VARIANTS);
  for (let i = 0; i < games; i++) {
    const gseed = (Math.imul(seed + i, 2654435761) ^ 0x85ebca6b) >>> 0;
    const rng = makeRng(gseed ^ 0xc2b2ae35);
    const n = 3 + (i % 4);
    const v = variant === 'mix' ? (i % 5 === 4 ? variantKeys[1 + Math.floor(rng() * (variantKeys.length - 1))] : 'officielle') : variant;
    const profiles = Array.from({ length: n }, () => ({
      style: styles[Math.floor(rng() * styles.length)],
      level: levels[Math.floor(rng() * levels.length)]
    }));
    specs.push({ game: i + 1, seed: gseed, n, variant: v, opts: VARIANTS[v], profiles });
  }
  return specs;
}

if (isMainThread && process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const args = Object.fromEntries(process.argv.slice(2).reduce((acc, a, i, arr) => {
    if (a.startsWith('--')) acc.push([a.slice(2), arr[i + 1] && !arr[i + 1].startsWith('--') ? arr[i + 1] : true]);
    return acc;
  }, []));
  const games = Number(args.games || 10);
  const seed = Number(args.seed || 1);
  const variant = args.variant || 'officielle';
  if (variant !== 'mix' && !VARIANTS[variant]) throw new Error('Variante inconnue ' + variant);
  const styles = (args.styles || Object.keys(STYLES).join(',')).split(',');
  const levels = (args.levels || Object.keys(LEVELS).join(',')).split(',');
  const workers = Math.max(1, Math.min(Number(args.workers || cpus().length - 1), games));
  const out = resolve(args.out || join('resultats', `run-${new Date().toISOString().slice(0, 16).replace(/[:T]/g, '-')}-${games}`));
  if (existsSync(out)) rmSync(out, { recursive: true });
  mkdirSync(out, { recursive: true });
  const specs = makeSpecs({ games, seed, variant, styles, levels });
  writeFileSync(join(out, 'config.json'), JSON.stringify({ games, seed, variant, styles, levels, workers, date: new Date().toISOString() }, null, 2));

  const { TABLES } = await import('./game.mjs');
  const t0 = Date.now();
  let done = 0, lastPct = -1;
  const errors = [];
  await Promise.all(Array.from({ length: workers }, (_, w) => new Promise((ok, ko) => {
    const mine = specs.filter((_, i) => i % workers === w);
    const worker = new Worker(fileURLToPath(import.meta.url), { workerData: { specs: mine, dir: join(out, 'parts'), w } });
    worker.on('message', m => {
      if (m.error) errors.push(m.error);
      done += m.done || 0;
      const pct = Math.floor((100 * done) / games / 10) * 10;
      if (pct !== lastPct) {
        lastPct = pct;
        const s = (Date.now() - t0) / 1000;
        console.log(`${pct}% (${done}/${games}) ${s.toFixed(0)} s`);
      }
    });
    worker.on('error', ko);
    worker.on('exit', ok);
  })));

  // Fusion des parties écrites par chaque worker.
  for (const [name, header] of Object.entries(TABLES)) {
    const file = join(out, name + '.csv');
    writeFileSync(file, header.join(',') + '\n');
    for (const f of readdirSync(join(out, 'parts')).filter(f => f.startsWith(name + '.')).sort()) {
      appendFileSync(file, readFileSync(join(out, 'parts', f)));
    }
  }
  rmSync(join(out, 'parts'), { recursive: true });
  if (errors.length) writeFileSync(join(out, 'erreurs.txt'), errors.join('\n'));
  console.log(`Terminé : ${games} parties en ${((Date.now() - t0) / 1000).toFixed(0)} s, ${errors.length} erreur(s). Dossier : ${out}`);
} else if (!isMainThread) {
  const { playGame } = await import('./game.mjs');
  const { specs, dir, w } = workerData;
  mkdirSync(dir, { recursive: true });
  const buf = { games: [], players: [], rounds: [], plays: [] };
  const flush = () => {
    for (const k of Object.keys(buf)) {
      if (buf[k].length) appendFileSync(join(dir, `${k}.${String(w).padStart(2, '0')}.csv`), buf[k].join(''));
      buf[k] = [];
    }
  };
  let pending = 0;
  for (const spec of specs) {
    try {
      const rows = playGame(spec);
      for (const k of Object.keys(buf)) for (const r of rows[k]) buf[k].push(csvLine(r));
    } catch (e) {
      parentPort.postMessage({ error: `partie ${spec.game} (graine ${spec.seed}) : ${e.stack}` });
    }
    pending++;
    if (pending >= 10) {
      flush();
      parentPort.postMessage({ done: pending });
      pending = 0;
    }
  }
  flush();
  parentPort.postMessage({ done: pending });
}
