// Tests des règles officielles (regle.html), scénario par scénario.  node --test tests/
import test from 'node:test';
import assert from 'node:assert/strict';
import { CARDS, buildDeck, createGame, startRound, act, finishRound, legalBets, forbiddenBet } from '../src/engine.mjs';
import { unseenFor, STYLES, LEVELS } from '../src/ai.mjs';
const ST = Object.keys(STYLES), LV = Object.keys(LEVELS);
import { playGame } from '../src/game.mjs';

const C = id => CARDS[id];
/** Partie à n joueurs, manche `cards`, mains imposées (listes d'id), donneur fixé. */
function setup(n, cards, hands, { dealer = n - 1, bets } = {}) {
  const s = createGame({ n, seed: 1, dealer, rounds: [cards] });
  startRound(s);
  hands.forEach((h, i) => { s.players[i].hand = h.map(C); });
  if (bets) for (const pid of s.round.betOrder) act(s, { type: 'bet', pid, value: bets[pid] });
  return s;
}
const play = (s, pid, cardId, mysticValue) => act(s, { type: 'play', pid, cardId, mysticValue });

test('matériel : 41 cartes à 3-4 joueurs (Pouvoirs 11, 27, 20, 3), 45 à 5-6', () => {
  for (const n of [3, 4]) {
    const d = buildDeck(n).map(c => c.id);
    assert.equal(d.length, 41);
    assert.deepEqual(d.filter(x => x.startsWith('p')).sort(), ['p11', 'p20', 'p27', 'p3']);
    assert.ok(d.includes('m'));
  }
  for (const n of [5, 6]) assert.equal(buildDeck(n).length, 45);
  assert.equal(C('p23').power, 'clairvoyance'); assert.equal(C('p4').power, 'sceau');
  assert.equal(C('p9').power, 'benediction'); assert.equal(C('p34').power, 'voile');
});

test('cycle 7 → 2 puis Mystique, donneur tournant, paris à gauche du donneur', () => {
  const s = createGame({ n: 4, seed: 3, dealer: 0 });
  const seen = [];
  startRound(s);
  for (let i = 0; i < 9; i++) {
    seen.push(s.round.cards);
    assert.equal(s.round.dealer, i % 4);
    assert.equal(s.round.betOrder[0], (s.round.dealer + 1) % 4);
    for (const p of s.players) assert.equal(p.hand.length, s.round.cards);
    s.roundNo++; s.roundNo--; // pas de finishRound : on enchaîne les distributions
    startRound(s);
  }
  assert.deepEqual(seen, [7, 6, 5, 4, 3, 2, 1, 7, 6]);
});

test("règle d'or : 5 cartes, paris 1, 2, 1 → le dernier ne peut pas dire 1", () => {
  const s = setup(4, 5, [['n1', 'n2', 'n3', 'n4', 'n5'], ['n6', 'n7', 'n8', 'n9', 'n10'], ['n11', 'n12', 'n13', 'n14', 'n15'], ['n16', 'n17', 'n18', 'n19', 'n20']]);
  const [a, b, c, last] = s.round.betOrder;
  act(s, { type: 'bet', pid: a, value: 1 }); act(s, { type: 'bet', pid: b, value: 2 }); act(s, { type: 'bet', pid: c, value: 1 });
  assert.equal(forbiddenBet(s, last), 1);
  assert.deepEqual(legalBets(s, last), [0, 2, 3, 4, 5]);
  assert.throws(() => act(s, { type: 'bet', pid: last, value: 1 }));
});

test('pli : la plus forte gagne, le Pouvoir bat le Nombre à égalité, le gagnant entame', () => {
  const s = setup(3, 2, [['n27', 'n1'], ['p27', 'n2'], ['n10', 'n3']], { dealer: 2, bets: [0, 1, 0] });
  play(s, 0, 'n27'); play(s, 1, 'p27');
  assert.equal(s.pending.type, 'target'); // Sceau : cible = joueur 2 (le seul qui n'a pas joué)
  assert.deepEqual(s.pending.options, [2]);
  act(s, { type: 'target', pid: 1, target: 2 });
  assert.equal(s.players[1].tricks, 1);
  assert.equal(s.trick.leader, 1);
});

test('Mystique hors manche Mystique : 37 gagne tout, 0 perd tout', () => {
  let s = setup(3, 1 + 1, [['m', 'n1'], ['n36', 'n2'], ['p27', 'n3']], { dealer: 2, bets: [1, 0, 0] });
  play(s, 0, 'm', 37); play(s, 1, 'n36'); play(s, 2, 'n3');
  assert.equal(s.players[0].tricks, 1);
  s = setup(3, 2, [['m', 'n1'], ['n5', 'n2'], ['n4', 'n3']], { dealer: 2, bets: [0, 1, 0] });
  play(s, 0, 'm', 0); play(s, 1, 'n5'); play(s, 2, 'n4');
  assert.equal(s.players[1].tricks, 1);
});

test('Sceau : annulé si joué en dernier ; sinon carte au hasard jouée immédiatement par la cible', () => {
  let s = setup(3, 2, [['n5', 'n1'], ['n6', 'n2'], ['p27', 'n3']], { dealer: 2, bets: [0, 0, 1] });
  play(s, 0, 'n5'); play(s, 1, 'n6'); play(s, 2, 'p27');
  assert.equal(s.players[2].tricks, 1); // pas de décision de cible : effet annulé
  s = setup(3, 2, [['p27', 'n1'], ['n6', 'n2'], ['n8', 'n9']], { dealer: 2, bets: [1, 0, 0] });
  play(s, 0, 'p27');
  act(s, { type: 'target', pid: 0, target: 2 });
  const forced = s.trick.plays[1];
  assert.equal(forced.pid, 2); assert.equal(forced.forcedBy, 'sceau');
  assert.equal(s.players[2].hand.length, 1);
  assert.equal(s.pending.pid, 1); // puis le tour reprend
});

test('Bénédiction : la cible pose sa carte la plus faible ; annulée en dernier', () => {
  const s = setup(3, 2, [['p20', 'n1'], ['n30', 'n2'], ['n8', 'n9']], { dealer: 2, bets: [1, 0, 0] });
  play(s, 0, 'p20');
  act(s, { type: 'target', pid: 0, target: 1 });
  assert.equal(s.trick.plays[1].card.id, 'n2');
  assert.equal(s.trick.plays[1].forcedBy, 'benediction');
});

test('Voile : annulé en premier ; sinon échange de valeur avec une carte posée par un adversaire', () => {
  let s = setup(3, 2, [['p3', 'n1'], ['n30', 'n2'], ['n8', 'n9']], { dealer: 2, bets: [0, 1, 0] });
  play(s, 0, 'p3');
  assert.equal(s.trick.plays[0].effect, 'annule');
  s = setup(3, 2, [['n30', 'n1'], ['p3', 'n2'], ['n8', 'n9']], { dealer: 2, bets: [0, 1, 0] });
  play(s, 0, 'n30'); play(s, 1, 'p3');
  assert.deepEqual(s.pending.options, [0]);
  act(s, { type: 'target', pid: 1, target: 0 });
  assert.equal(s.trick.plays[1].value, 30); assert.equal(s.trick.plays[0].value, 3);
  play(s, 2, 'n8');
  assert.equal(s.players[1].tricks, 1);
});

test('Clairvoyance : voit la carte la plus forte de la cible', () => {
  const s = setup(3, 3, [['p11', 'n1', 'n2'], ['n30', 'n3', 'm'], ['n8', 'n9', 'n10']], { dealer: 2, bets: [0, 1, 1] });
  play(s, 0, 'p11');
  act(s, { type: 'target', pid: 0, target: 1 });
  assert.deepEqual(s.players[0].peeks, [{ target: 1, id: 'm' }]);
});

test('manche Mystique : carte invisible pour soi, pouvoirs inactifs, Mystique = 37 si pari 1', () => {
  const s = setup(3, 1, [['m'], ['p34'], ['n36']], { dealer: 2 });
  assert.ok(s.round.mystic);
  assert.ok(unseenFor(s, 0).some(c => c.id === 'm'));        // ne voit pas sa propre carte
  assert.ok(!unseenFor(s, 0).some(c => c.id === 'n36'));     // voit celle des autres
  // Paris 1, 1, 0 (1, 0, 0 serait interdit par la règle d'or : somme = 1 pli).
  act(s, { type: 'bet', pid: 0, value: 1 }); act(s, { type: 'bet', pid: 1, value: 1 });
  assert.equal(forbiddenBet(s, 2), null);
  act(s, { type: 'bet', pid: 2, value: 0 });
  assert.equal(s.phase, 'roundEnd');
  assert.ok(s.round.played.some(c => c.id === 'p34'));
  assert.equal(s.players[0].tricks, 1);                      // Mystique à 37 bat le 36
  const res = finishRound(s);
  assert.deepEqual(res.map(x => x.lost), [0, 1, 0]);         // raté = 1 Vie
});

test('Vies : pari raté = écart ; fin au premier joueur à 0 Vie ; égalité → départage Mystique', () => {
  const s = setup(3, 2, [['n36', 'n35'], ['n1', 'n2'], ['n3', 'n4']], { dealer: 2, bets: [0, 0, 1] });
  s.players[0].lives = 2;
  play(s, 0, 'n36'); play(s, 1, 'n1'); play(s, 2, 'n3');
  play(s, 0, 'n35'); play(s, 1, 'n2'); play(s, 2, 'n4');
  const res = finishRound(s);
  assert.equal(res.find(x => x.pid === 0).lost, 2);   // pari 0, 2 plis
  assert.equal(res.find(x => x.pid === 2).lost, 1);   // pari 1, 0 pli
  assert.equal(s.players[0].lives, 0);
  // joueurs 1 (5 Vies) et 2 (4 Vies) : joueur 1 seul en tête → gagne sans départage
  assert.ok(s.over); assert.deepEqual(s.winners, [1]);
});

test('parties complètes : 3 à 6 joueurs, tous styles et niveaux, aucune erreur, chaque partie se termine', () => {
  for (let i = 0; i < 40; i++) {
    const n = 3 + (i % 4);
    const rows = playGame({ game: i, seed: 1000 + i, n, variant: 'officielle', opts: {},
      profiles: Array.from({ length: n }, (_, k) => ({ style: ST[(i + k) % ST.length], level: LV[(3 * i + k) % LV.length] })) });
    assert.equal(rows.games.length, 1);
    assert.ok(rows.games[0][10] >= 1);
  }
});

test('même graine = même partie ; les donnes ne dépendent pas des choix des joueurs', () => {
  const spec = lv => ({ game: 1, seed: 4242, n: 4, variant: 'officielle', opts: {}, profiles: Array.from({ length: 4 }, () => ({ style: 'calculateur', level: lv })) });
  const strip = rows => JSON.stringify({ ...rows, games: rows.games.map(g => g.filter((_, i) => i !== 18)) });   // sans la colonne ms
  assert.equal(strip(playGame(spec('confirme'))), strip(playGame(spec('confirme'))));
  const hands = lv => playGame(spec(lv)).rounds.filter(r => r[3] < 3).map(r => r[29]).join('/');
  assert.equal(hands('novice'), hands('confirme'));   // mêmes mains aux 3 premières manches, quel que soit le niveau
});
